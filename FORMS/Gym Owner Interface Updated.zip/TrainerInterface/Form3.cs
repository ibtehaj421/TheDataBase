﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TrainerInterface
{
    public partial class AdminDash : Form
    {
        private MemberDiet diet = null;
        private MemberWork plan = null;
        private MemberTrainers train = null;
        private MemberMetric metric = null;
        public AdminDash()
        {
            InitializeComponent();
            RunFunctions();
        }
        public AdminDash(MemberDiet other)
        {
            diet = other;
            InitializeComponent();
            RunFunctions();
        }
        public AdminDash(MemberWork other)
        {
            plan = other;
            InitializeComponent();
            RunFunctions();
        }
        public AdminDash(MemberTrainers other)
        {
            train = other;
            InitializeComponent();
            RunFunctions();
        }
        public AdminDash(MemberMetric other)
        {
            metric = other;
            InitializeComponent();
            RunFunctions();
        }

        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            DIET.MouseEnter += DIET_MouseEnterDIET;
            DIET.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            change.MouseEnter += Change_MouseEnter;
            change.MouseLeave += Change_MouseLeave;
            Numsets.Text = "Gym"; //specifies which gym has a pending request
            dashGym.Text = "Gym"; //specifies which gym has a pending request
        }
        private void Change_MouseEnter(object sender, EventArgs e)
        {
            change.BackColor = Color.LightGreen;
            change.ForeColor = Color.Azure;
        }
        private void Change_MouseLeave(object sender, EventArgs e)
        {
            change.BackColor = Color.Transparent;
        }
        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
            logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.SlateGray;

        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            DIET.BackColor = Color.Aqua;
            DIET.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            DIET.BackColor = Color.Transparent;
            DIET.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (diet != null)
            {
                diet.Close();
            }
            if (plan != null)
            {
                plan.Close();
            }
            if (metric != null)
            {
                metric.Close();
            }
            if (train != null)
            {
                train.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            //diet = new MemberDiet(this);
            //this.Hide();
            //diet.FormClosed += (s, args) => this.Close();
            //diet.Show();
        }
        private void SetCurrentPlanTable()
        {

        }
        private void change_Click(object sender, EventArgs e)
        {

        }

        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void PLAN_Click(object sender, EventArgs e)
        {
            //plan = new MemberWork(this);
            //this.Hide();
            //plan.FormClosed += (s, args) => this.Close();
            //plan.Show();
        }

        private void metrics_Click(object sender, EventArgs e)
        {
            //metric = new MemberMetric(this);
            //this.Hide();
            //metric.FormClosed += (s, args) => this.Close();
            //metric.Show();
        }

        private void trainers_Click(object sender, EventArgs e)
        {
            //train = new MemberTrainers(this);
            //this.Hide();
            //train.FormClosed += (s, args) => this.Close();
            //train.Show();
        }
    }
}
