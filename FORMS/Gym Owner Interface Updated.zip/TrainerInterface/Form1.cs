﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace TrainerInterface
{
    public partial class Form1 : Form
    {
        public static string username = "";
        public static string email = "";
        public static string password = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.ForeColor = Color.Red;
            panel1.BackColor = Color.Red;
        }
        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                textBox2.Clear();

            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox3.ForeColor = Color.Red;
            panel3.BackColor = Color.Red;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                 textBox2.Clear();
          
            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Create an instance of the login form
            Form2 registrationForm = new Form2();

            this.Hide();
            registrationForm.Closed += (s, args) => this.Close();
            // Show the login form
            registrationForm.Show();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            username = textBox1.Text;
            password = textBox2.Text;
            email = textBox3.Text;
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT * FROM Owner WHERE username = '" + username + "' AND email = '" + email + "' AND password = '" + password + "'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("Login Successful");
                conn.Close();
                // Create an instance of the Dashboard
                Dashboard dashboard = new Dashboard();

                this.Hide();
                dashboard.Closed += (s, args) => this.Close();
                // Show the Dashboard
                dashboard.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username/Password");
                conn.Close();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
