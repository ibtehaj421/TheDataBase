﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class MemberMetric : Form
    {
        private MemberDash dash = null;
        private MemberWork plan = null;
        private MemberTrainers train = null;
        private MemberDiet diet = null;
        public string memberID; //every form will pass through this information for use of each form.
        private bool show = true;
        private string query;
        private string connectionString;
        public MemberMetric()
        {
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberMetric(MemberDash other)
        {
            dash = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberMetric(MemberDiet other)
        {
            diet = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberMetric(MemberWork other)
        {
            plan = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberMetric(MemberTrainers other)
        {
            train = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            dashboard.MouseEnter += DIET_MouseEnterDIET;
            dashboard.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            filter.MouseEnter += Filter_MouseEnter;
            filter.MouseLeave += Filter_MouseLeave;
            report.MouseLeave += Report_MouseLeave;
            report.MouseEnter += Report_MouseEnter;
            filter2.MouseEnter += Filter2_MouseEnter;
            filter2.MouseLeave += Filter2_MouseLeave;
            report2.MouseEnter += Report2_MouseEnter;
            report2.MouseLeave += Report2_MouseLeave;
            button2.MouseEnter += Button2_MouseEnter;
            button2.MouseLeave += Button2_MouseLeave;
            button1.MouseEnter += Button1_MouseEnter;
            button1.MouseLeave += Button1_MouseLeave;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.ForeColor = Color.SlateGray;
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.Azure;
        }

        private void Button2_MouseLeave(object sender, EventArgs e)
        {
            button2.ForeColor = Color.SlateGray;
        }

        private void Button2_MouseEnter(object sender, EventArgs e)
        {
            button2.ForeColor = Color.Azure;
        }

        private void Report2_MouseLeave(object sender, EventArgs e)
        {
            report2.BackColor = Color.Transparent;
            report2.ForeColor = Color.SlateGray;
        }

        private void Report2_MouseEnter(object sender, EventArgs e)
        {
            report2.BackColor = Color.LightGreen;
            report2.ForeColor = Color.Azure;
        }

        private void Filter2_MouseEnter(object sender, EventArgs e)
        {
            filter2.BackColor = Color.LightGreen;
            filter2.ForeColor = Color.Azure;
        }
        private void Filter2_MouseLeave(object sender, EventArgs e)
        {
            filter2.BackColor = Color.Transparent;
            filter2.ForeColor = Color.SlateGray;
        }
        private void Report_MouseEnter(object sender, EventArgs e)
        {
            report.BackColor = Color.LightGreen;
            report.ForeColor = Color.Azure;
        }

        private void Report_MouseLeave(object sender, EventArgs e)
        {
            report.BackColor = Color.Transparent;
            report.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseLeave(object sender, EventArgs e)
        {
            filter.BackColor = Color.Transparent;
            filter.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseEnter(object sender, EventArgs e)
        {
            filter.BackColor = Color.LightGreen;
            filter.ForeColor = Color.Azure;
        }



        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
            logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.SlateGray;

        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Aqua;
            dashboard.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Transparent;
            dashboard.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            //metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (diet != null)
            {
                diet.Close();
            }
            if (plan != null)
            {
                plan.Close();
            }
            if (dash != null)
            {
                dash.Close();
            }
            if (train != null)
            {
                train.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            //move to the diet form do nothing for now.
            diet = new MemberDiet(this);
            diet.memberID = memberID;
            this.Hide();
            diet.FormClosed += (s, args) => this.Close();
            diet.Show();
        }

        private void change_Click(object sender, EventArgs e)
        {

        }

        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void welcome_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void filter_Click(object sender, EventArgs e)
        {

        }

        private void dashboard_Click(object sender, EventArgs e)
        {
            dash = new MemberDash(this);
            dash.memberID = this.memberID;
            this.Hide();
            dash.FormClosed += (s, args) => this.Close();
            dash.Show();
        }

        private void PLAN_Click(object sender, EventArgs e)
        {
            plan = new MemberWork(this);
            plan.memberID = this.memberID;
            this.Hide();
            plan.FormClosed += (s, args) => this.Close();
            plan.Show();
        }

        private void trainers_Click(object sender, EventArgs e)
        {
            train = new MemberTrainers(this);
            train.memberID = this.memberID;
            this.Hide();
            train.FormClosed += (s, args) => this.Close();
            train.Show();
        }

        private void report_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //filter the trainer you want to add for.
            DataTable table = new DataTable();
            if (comboBox3.Text.Length == 0)
            {
                trainerPrompt.ForeColor = Color.Red;
                trainerPrompt.Text = "Choose A Filter.";
            }
            else if(comboBox3.Text == "Your Trainers")
            {
                query = "WITH SpecificTrainer AS(\r\n\tSELECT trainer_id,gym_id FROM TRAINING_SESSION WHERE member_id = '" + memberID + "'\r\n\t)\r\n\tSELECT T.name as tname,G.name as gname,T.trainer_id,G.gym_id FROM SpecificTrainer ST JOIN TRAINER T ON ST.trainer_id = T.trainer_id JOIN GYM G ON ST.gym_id = G.gym_id;";

            }
            else if(comboBox3.Text == "Gym Trainers")
            {
                query = "WITH specific AS(\r\n\tSELECT membership_id FROM MEMBER WHERE member_id ='" + memberID + "'\r\n\t),\r\n\tspecificGym AS(\r\n\tSELECT gym_id FROM Membership M JOIN specific S on M.membership_id = S.membership_id\r\n\t),\r\n\tspecificTrain AS(\r\n\tSELECT trainer_id FROM TRAINER_GYM T JOIN specificGym S ON T.gym_id = S.gym_id\r\n\t)\r\n\tSELECT T.name,T.trainer_id FROM specificTrain S join TRAINER T on T.trainer_id = S.trainer_id; ";
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            string toAdd;
            string select;
            TrainerSelection.Items.Clear();
            
            foreach (DataRow row in table.Rows)
            {
                toAdd = row["tname"].ToString();
                select = row["trainer_id"].ToString();
                TrainerSelection.Items.Add(toAdd + "," + select);
            }
        }

        private void filter2_Click(object sender, EventArgs e)
        {
            //filter gyms
            //not gonna do this for now as it not required.
        }

        private void report2_Click(object sender, EventArgs e)
        {
            //add a review for the gym.
            string gymID = chooseGym.Text;
            string[] idArray = gymID.Split(',');
            string trimID = idArray[1].Trim();
            float rate = float.Parse(gymRating.Text);
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            query = "EXEC AddGymReview @gymID='" + trimID + "' ,@feedback='" + richTextBox2.Text + "' ,@rating=" + rate + " ;";
            if (chooseGym.Text.Length == 0 || gymRating.Text.Length == 0 || richTextBox2.Text.Length == 0)
            {
                gymPrompt.ForeColor = Color.Red;
                gymPrompt.Text = "Choose Selections!";
                timer2.Interval = 1000;
                timer2.Start();
                conn.Close();
            }
            else
            {
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                gymPrompt.ForeColor = Color.Green;
                gymPrompt.Text = "Review Submitted..";
                timer2.Interval = 1000;
                timer2.Start();
            }
        }
        private void SetInitials()
        {
            //load data into all combo boxes.
            //trainerSelection and choose Gym.
            connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            DataTable table = new DataTable();
            query = "WITH SpecificTrainer AS(\r\n\tSELECT trainer_id,gym_id FROM TRAINING_SESSION WHERE member_id = '"+memberID+"'\r\n\t)\r\n\tSELECT T.name as tname,G.name as gname,T.trainer_id,G.gym_id FROM SpecificTrainer ST JOIN TRAINER T ON ST.trainer_id = T.trainer_id JOIN GYM G ON ST.gym_id = G.gym_id;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            string toAdd;
            string select;
            TrainerSelection.Items.Clear();
            chooseGym.Items.Clear();
            foreach (DataRow row in table.Rows)
            {
                toAdd = row["tname"].ToString();
                select = row["trainer_id"].ToString();
                TrainerSelection.Items.Add(toAdd+","+select);
                toAdd = row["gname"].ToString();
                select = row["gym_id"].ToString() ;
                chooseGym.Items.Add(toAdd + "," + select);
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            SetInitials();
            //call relevant functions based on memberID.
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //used for the prompt.
            trainerPrompt.Text = "";
            timer2.Stop();
            gymPrompt.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //for the trainer review add a review.
            string trainerID = TrainerSelection.Text;
            string[] idArray = trainerID.Split(',');
            string trimID = idArray[1].Trim();
            float rate = float.Parse(comboBox2.Text);
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            query = "EXEC AddTrainerReview @trainerID='" + trimID + "' ,@feedback='" + richTextBox1.Text + "' ,@rating=" + rate + " ;";
            if (TrainerSelection.Text.Length == 0 || comboBox2.Text.Length == 0 || richTextBox1.Text.Length == 0)
            {
                trainerPrompt.ForeColor = Color.Red;
                trainerPrompt.Text = "Choose Selections!";
                timer2.Interval = 1000;
                timer2.Start();
                conn.Close();
            }
            else
            {
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                trainerPrompt.ForeColor = Color.Green;
                trainerPrompt.Text = "Review Submitted..";
                timer2.Interval = 1000;
                timer2.Start();
            }
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
