﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class MemberReg : Form
    {
        bool show = true;
        private MemberDash dash = null;
        public MemberReg()
        {
            InitializeComponent();
            exitLogin.MouseEnter += OnMouseEnterExitLogin;
            exitLogin.MouseLeave += OnMouseLeaveExitLogin;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            button1.MouseEnter += OnMouseEnterFilter;
            button1.MouseLeave += OnMouseLeaveFilter;
            if(show)
            {
                showAll();
                show = false; //show only once per load.
            }
        }
        private void showAll()
        {
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            string sqlQuery = "SELECT name FROM GYM"; // Replace with your actual query

            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            string itemToAdd;
            foreach (DataRow row in dataTable.Rows)
            {
                itemToAdd = row["name"].ToString(); // Assuming "ColumnName" holds the data to display
                GymList.Items.Add(itemToAdd);
            }
        }
        private void OnMouseEnterFilter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.White;
            button1.BackColor = Color.SeaGreen;
        }
        private void OnMouseLeaveFilter(object sender, EventArgs e)
        {
            button1.ForeColor = Color.Transparent;
            button1.BackColor = Color.Transparent;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            //textBox1.Clear();
            //textBox1.ForeColor = Color.Red;
            //panel1.BackColor = Color.Red;
        }
        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                textBox2.Clear();

            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox3.ForeColor = Color.Red;
            panel3.BackColor = Color.Red;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                 textBox2.Clear();
          
            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        private void OnMouseEnterExitLogin(object sender, EventArgs e)
        {
            exitLogin.ForeColor = Color.White;
        }
        private void OnMouseLeaveExitLogin(object sender, EventArgs e)
        {
            exitLogin.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }
        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exitLogin_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //catches a string that then initiates a query on that string
            string typeSpecifier = GymList.Text.ToString();
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
           

           
            if (typeSpecifier.Length < 3)
            {
                GymList.Items.Clear();
                int line = int.Parse(typeSpecifier);
                string sqlQuery = "SELECT name FROM GYM WHERE rating > " + line + ";"; // Replace with your actual query
                DataTable dataTable = new DataTable();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataTable);
                        }
                    }
                }
                //perform a rating based search
                string itemToAdd;
                foreach (DataRow row in dataTable.Rows)
                {
                    itemToAdd = row["name"].ToString(); // Assuming "ColumnName" holds the data to display
                    GymList.Items.Add(itemToAdd);
                }

            }
            else if(typeSpecifier == "All")
            {
                GymList.Items.Clear();
                showAll();
            }
            else
            {
                GymList.Items.Clear();
                string line= typeSpecifier;
                //perfrom a location based search else show all gyms as it is.
                string sqlQuery = "SELECT name FROM GYM WHERE location = '" + line + "';"; // Replace with your actual query
                DataTable dataTable = new DataTable();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataTable);
                        }
                    }
                }
                string itemToAdd;
                foreach (DataRow row in dataTable.Rows)
                {
                    itemToAdd = row["name"].ToString(); // Assuming "ColumnName" holds the data to display
                    GymList.Items.Add(itemToAdd);
                }
            }
        }

        private void Login_Click(object sender, EventArgs e)
        {
            //call procedure to insert into the database.
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            string name = fname.Text.ToString();
            string email = textBox3.Text.ToString();
            string password = textBox2.Text.ToString();
            string gymName = GymList.Text.ToString();
            string type = MemberShipType.Text.ToString();
            if(email.Length ==0 || name.Length ==0 || password.Length == 0 || gymName.Length == 0 || type.Length == 0)
            {
                label1.Text = "Please fill in the details.";
            }
            else if (!email.Contains("@gmail.com"))
            {
                label1.Text = "Invalid email";
            }
            else
            {
                //proceed with the insertion
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand cmd;
                string query = "EXEC RegisterMemberDetails @usrnem ="+ "'"+ name + "'"+",@email=" + "'"+ email + "'"+ ",@pass="+ "'"+ password + "'" + ",@type=" + "'" + type + "'"+",@gname=" + "'" + gymName + "'" + ";";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cmd.Clone();
                dash = new MemberDash();
                this.Hide();
                dash.FormClosed += (s, args) => this.Close();
                dash.Show();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
