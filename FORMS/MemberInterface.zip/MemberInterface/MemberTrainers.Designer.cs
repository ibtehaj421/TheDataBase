﻿using System.Drawing;

namespace TrainerInterface
{
    partial class MemberTrainers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberTrainers));
            this.menu = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.trainers = new System.Windows.Forms.Button();
            this.metrics = new System.Windows.Forms.Button();
            this.PLAN = new System.Windows.Forms.Button();
            this.DIET = new System.Windows.Forms.Button();
            this.dashboard = new System.Windows.Forms.Button();
            this.userInfo = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.topside = new System.Windows.Forms.Panel();
            this.minimize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.welcome = new System.Windows.Forms.Label();
            this.addDiet = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.prompt = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ratingBox = new System.Windows.Forms.ComboBox();
            this.expBox = new System.Windows.Forms.ComboBox();
            this.trainerFilter = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dietTable = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.filter = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.sessionList = new System.Windows.Forms.ComboBox();
            this.menu.SuspendLayout();
            this.userInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.topside.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.dietTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.menu.Controls.Add(this.logout);
            this.menu.Controls.Add(this.trainers);
            this.menu.Controls.Add(this.metrics);
            this.menu.Controls.Add(this.PLAN);
            this.menu.Controls.Add(this.DIET);
            this.menu.Controls.Add(this.dashboard);
            this.menu.Controls.Add(this.userInfo);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(200, 669);
            this.menu.TabIndex = 0;
            this.menu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // logout
            // 
            this.logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleVioletRed;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.SlateGray;
            this.logout.Location = new System.Drawing.Point(0, 628);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(200, 41);
            this.logout.TabIndex = 6;
            this.logout.Text = "LOGOUT";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // trainers
            // 
            this.trainers.BackColor = System.Drawing.Color.DodgerBlue;
            this.trainers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trainers.Dock = System.Windows.Forms.DockStyle.Top;
            this.trainers.FlatAppearance.BorderSize = 0;
            this.trainers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.trainers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.trainers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trainers.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainers.ForeColor = System.Drawing.Color.Azure;
            this.trainers.Location = new System.Drawing.Point(0, 344);
            this.trainers.Name = "trainers";
            this.trainers.Size = new System.Drawing.Size(200, 41);
            this.trainers.TabIndex = 5;
            this.trainers.Text = "TRAINERS";
            this.trainers.UseVisualStyleBackColor = false;
            // 
            // metrics
            // 
            this.metrics.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metrics.Dock = System.Windows.Forms.DockStyle.Top;
            this.metrics.FlatAppearance.BorderSize = 0;
            this.metrics.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.metrics.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.metrics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.metrics.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metrics.ForeColor = System.Drawing.Color.SlateGray;
            this.metrics.Location = new System.Drawing.Point(0, 303);
            this.metrics.Name = "metrics";
            this.metrics.Size = new System.Drawing.Size(200, 41);
            this.metrics.TabIndex = 4;
            this.metrics.Text = "METRICS";
            this.metrics.UseVisualStyleBackColor = true;
            this.metrics.Click += new System.EventHandler(this.metrics_Click);
            // 
            // PLAN
            // 
            this.PLAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PLAN.Dock = System.Windows.Forms.DockStyle.Top;
            this.PLAN.FlatAppearance.BorderSize = 0;
            this.PLAN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.PLAN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PLAN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PLAN.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLAN.ForeColor = System.Drawing.Color.SlateGray;
            this.PLAN.Location = new System.Drawing.Point(0, 262);
            this.PLAN.Name = "PLAN";
            this.PLAN.Size = new System.Drawing.Size(200, 41);
            this.PLAN.TabIndex = 3;
            this.PLAN.Text = "WORK PLAN";
            this.PLAN.UseVisualStyleBackColor = true;
            this.PLAN.Click += new System.EventHandler(this.PLAN_Click);
            // 
            // DIET
            // 
            this.DIET.BackColor = System.Drawing.Color.Transparent;
            this.DIET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DIET.Dock = System.Windows.Forms.DockStyle.Top;
            this.DIET.FlatAppearance.BorderSize = 0;
            this.DIET.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.DIET.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.DIET.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DIET.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DIET.ForeColor = System.Drawing.Color.SlateGray;
            this.DIET.Location = new System.Drawing.Point(0, 221);
            this.DIET.Name = "DIET";
            this.DIET.Size = new System.Drawing.Size(200, 41);
            this.DIET.TabIndex = 2;
            this.DIET.Text = "DIET";
            this.DIET.UseVisualStyleBackColor = false;
            this.DIET.Click += new System.EventHandler(this.DIET_Click);
            // 
            // dashboard
            // 
            this.dashboard.BackColor = System.Drawing.Color.Transparent;
            this.dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.dashboard.FlatAppearance.BorderSize = 0;
            this.dashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.dashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard.ForeColor = System.Drawing.Color.SlateGray;
            this.dashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard.Location = new System.Drawing.Point(0, 180);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(200, 41);
            this.dashboard.TabIndex = 1;
            this.dashboard.Text = "DASHBOARD";
            this.dashboard.UseVisualStyleBackColor = false;
            this.dashboard.Click += new System.EventHandler(this.dashboard_Click);
            // 
            // userInfo
            // 
            this.userInfo.Controls.Add(this.logo);
            this.userInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.userInfo.Location = new System.Drawing.Point(0, 0);
            this.userInfo.Name = "userInfo";
            this.userInfo.Size = new System.Drawing.Size(200, 180);
            this.userInfo.TabIndex = 0;
            // 
            // logo
            // 
            this.logo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logo.BackgroundImage")));
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logo.Location = new System.Drawing.Point(36, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(127, 128);
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            // 
            // topside
            // 
            this.topside.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.topside.Controls.Add(this.minimize);
            this.topside.Controls.Add(this.exit);
            this.topside.Dock = System.Windows.Forms.DockStyle.Top;
            this.topside.Location = new System.Drawing.Point(200, 0);
            this.topside.Name = "topside";
            this.topside.Size = new System.Drawing.Size(1012, 38);
            this.topside.TabIndex = 1;
            // 
            // minimize
            // 
            this.minimize.BackColor = System.Drawing.Color.Transparent;
            this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimize.FlatAppearance.BorderSize = 0;
            this.minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize.ForeColor = System.Drawing.Color.DimGray;
            this.minimize.Location = new System.Drawing.Point(940, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(36, 38);
            this.minimize.TabIndex = 1;
            this.minimize.Text = "-";
            this.minimize.UseVisualStyleBackColor = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.DimGray;
            this.exit.Location = new System.Drawing.Point(976, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(36, 38);
            this.exit.TabIndex = 0;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // welcome
            // 
            this.welcome.AutoSize = true;
            this.welcome.Font = new System.Drawing.Font("Cascadia Code", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome.ForeColor = System.Drawing.Color.White;
            this.welcome.Location = new System.Drawing.Point(15, 22);
            this.welcome.Name = "welcome";
            this.welcome.Size = new System.Drawing.Size(143, 35);
            this.welcome.TabIndex = 8;
            this.welcome.Text = "TRAINERS";
            this.welcome.Click += new System.EventHandler(this.welcome_Click);
            // 
            // addDiet
            // 
            this.addDiet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addDiet.FlatAppearance.BorderSize = 0;
            this.addDiet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.addDiet.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.addDiet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addDiet.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDiet.ForeColor = System.Drawing.Color.SlateGray;
            this.addDiet.Location = new System.Drawing.Point(1000, 62);
            this.addDiet.Name = "addDiet";
            this.addDiet.Size = new System.Drawing.Size(200, 41);
            this.addDiet.TabIndex = 14;
            this.addDiet.Text = "REQUEST SESSION";
            this.addDiet.UseVisualStyleBackColor = true;
            this.addDiet.Click += new System.EventHandler(this.addDiet_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.panel1.Controls.Add(this.prompt);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.ratingBox);
            this.panel1.Controls.Add(this.expBox);
            this.panel1.Controls.Add(this.trainerFilter);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.filter);
            this.panel1.Controls.Add(this.welcome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(200, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 631);
            this.panel1.TabIndex = 15;
            // 
            // prompt
            // 
            this.prompt.AutoSize = true;
            this.prompt.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prompt.ForeColor = System.Drawing.Color.White;
            this.prompt.Location = new System.Drawing.Point(275, 44);
            this.prompt.Name = "prompt";
            this.prompt.Size = new System.Drawing.Size(0, 16);
            this.prompt.TabIndex = 34;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(161, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 15);
            this.label8.TabIndex = 33;
            this.label8.Text = "Rating";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(161, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 32;
            this.label2.Text = "Experience";
            // 
            // ratingBox
            // 
            this.ratingBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.ratingBox.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratingBox.ForeColor = System.Drawing.Color.White;
            this.ratingBox.FormattingEnabled = true;
            this.ratingBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.ratingBox.Location = new System.Drawing.Point(164, 154);
            this.ratingBox.Name = "ratingBox";
            this.ratingBox.Size = new System.Drawing.Size(124, 23);
            this.ratingBox.TabIndex = 31;
            // 
            // expBox
            // 
            this.expBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.expBox.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expBox.ForeColor = System.Drawing.Color.White;
            this.expBox.FormattingEnabled = true;
            this.expBox.Items.AddRange(new object[] {
            "1 year",
            "2 years",
            "3 years",
            "4 years",
            "5 years",
            "6 years",
            "7 years",
            "8 years"});
            this.expBox.Location = new System.Drawing.Point(164, 107);
            this.expBox.Name = "expBox";
            this.expBox.Size = new System.Drawing.Size(124, 23);
            this.expBox.TabIndex = 30;
            // 
            // trainerFilter
            // 
            this.trainerFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.trainerFilter.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainerFilter.ForeColor = System.Drawing.Color.White;
            this.trainerFilter.FormattingEnabled = true;
            this.trainerFilter.Items.AddRange(new object[] {
            "All",
            "Personal",
            "Rating",
            "Experience"});
            this.trainerFilter.Location = new System.Drawing.Point(21, 107);
            this.trainerFilter.Name = "trainerFilter";
            this.trainerFilter.Size = new System.Drawing.Size(124, 23);
            this.trainerFilter.TabIndex = 29;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(0, 206);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 167);
            this.panel2.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.AutoSize = true;
            this.panel3.Controls.Add(this.dietTable);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(539, 167);
            this.panel3.TabIndex = 0;
            // 
            // dietTable
            // 
            this.dietTable.AutoScroll = true;
            this.dietTable.AutoSize = true;
            this.dietTable.ColumnCount = 5;
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.Controls.Add(this.label3, 3, 0);
            this.dietTable.Controls.Add(this.label4, 2, 0);
            this.dietTable.Controls.Add(this.label5, 1, 0);
            this.dietTable.Controls.Add(this.label6, 0, 0);
            this.dietTable.Controls.Add(this.label7, 4, 0);
            this.dietTable.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dietTable.Location = new System.Drawing.Point(3, 3);
            this.dietTable.Name = "dietTable";
            this.dietTable.RowCount = 2;
            this.dietTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.dietTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.dietTable.Size = new System.Drawing.Size(452, 69);
            this.dietTable.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(132, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 21);
            this.label3.TabIndex = 14;
            this.label3.Text = "Experience";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(89, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 21);
            this.label4.TabIndex = 14;
            this.label4.Text = "Gym";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(37, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 21);
            this.label5.TabIndex = 14;
            this.label5.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 21);
            this.label6.TabIndex = 14;
            this.label6.Text = "ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(238, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 21);
            this.label7.TabIndex = 15;
            this.label7.Text = "Rating";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(21, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "Filter";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // filter
            // 
            this.filter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.filter.FlatAppearance.BorderSize = 0;
            this.filter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.filter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filter.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filter.ForeColor = System.Drawing.Color.SlateGray;
            this.filter.Location = new System.Drawing.Point(367, 95);
            this.filter.Name = "filter";
            this.filter.Size = new System.Drawing.Size(138, 41);
            this.filter.TabIndex = 19;
            this.filter.Text = "Filter";
            this.filter.UseVisualStyleBackColor = true;
            this.filter.Click += new System.EventHandler(this.filter_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(742, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 15);
            this.label10.TabIndex = 22;
            this.label10.Text = "Select List";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // sessionList
            // 
            this.sessionList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.sessionList.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sessionList.ForeColor = System.Drawing.Color.White;
            this.sessionList.FormattingEnabled = true;
            this.sessionList.Location = new System.Drawing.Point(745, 123);
            this.sessionList.Name = "sessionList";
            this.sessionList.Size = new System.Drawing.Size(124, 23);
            this.sessionList.TabIndex = 31;
            // 
            // MemberTrainers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.ClientSize = new System.Drawing.Size(1212, 669);
            this.Controls.Add(this.sessionList);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.addDiet);
            this.Controls.Add(this.topside);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MemberTrainers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberDash";
            this.menu.ResumeLayout(false);
            this.userInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.topside.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.dietTable.ResumeLayout(false);
            this.dietTable.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public void MenuFormat()
        {
            menu.BackColor = Color.FromArgb(11, 35, 61);
            menu.Dock = System.Windows.Forms.DockStyle.Left;
        }
        public void TopFormat()
        {
            topside.BackColor = Color.LavenderBlush;
            topside.Dock = System.Windows.Forms.DockStyle.Top;
        }
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Panel topside;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel userInfo;
        private System.Windows.Forms.Button dashboard;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button DIET;
        private System.Windows.Forms.Button metrics;
        private System.Windows.Forms.Button PLAN;
        private System.Windows.Forms.Button trainers;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label welcome;
        private System.Windows.Forms.Button addDiet;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button filter;
        private System.Windows.Forms.TableLayoutPanel dietTable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox trainerFilter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ratingBox;
        private System.Windows.Forms.ComboBox expBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label prompt;
        private System.Windows.Forms.ComboBox sessionList;
    }
}