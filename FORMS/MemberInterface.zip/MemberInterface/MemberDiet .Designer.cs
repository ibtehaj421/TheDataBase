﻿using System.Drawing;

namespace TrainerInterface
{
    partial class MemberDiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberDiet));
            this.menu = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.trainers = new System.Windows.Forms.Button();
            this.metrics = new System.Windows.Forms.Button();
            this.PLAN = new System.Windows.Forms.Button();
            this.DIET = new System.Windows.Forms.Button();
            this.dashboard = new System.Windows.Forms.Button();
            this.userInfo = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.topside = new System.Windows.Forms.Panel();
            this.minimize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.welcome = new System.Windows.Forms.Label();
            this.addDiet = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.prompt = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dietTable = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TrainersPlans = new System.Windows.Forms.ComboBox();
            this.memberPlans = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.report = new System.Windows.Forms.Button();
            this.filter = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.guideline = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.nutri1 = new System.Windows.Forms.ComboBox();
            this.nutri2 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dietType = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.difficulty = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.success = new System.Windows.Forms.Label();
            this.setCurr = new System.Windows.Forms.Button();
            this.dietSelectList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menu.SuspendLayout();
            this.userInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.topside.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.dietTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.menu.Controls.Add(this.logout);
            this.menu.Controls.Add(this.trainers);
            this.menu.Controls.Add(this.metrics);
            this.menu.Controls.Add(this.PLAN);
            this.menu.Controls.Add(this.DIET);
            this.menu.Controls.Add(this.dashboard);
            this.menu.Controls.Add(this.userInfo);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(200, 669);
            this.menu.TabIndex = 0;
            this.menu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // logout
            // 
            this.logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleVioletRed;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.SlateGray;
            this.logout.Location = new System.Drawing.Point(0, 628);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(200, 41);
            this.logout.TabIndex = 6;
            this.logout.Text = "LOGOUT";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // trainers
            // 
            this.trainers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trainers.Dock = System.Windows.Forms.DockStyle.Top;
            this.trainers.FlatAppearance.BorderSize = 0;
            this.trainers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.trainers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.trainers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trainers.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainers.ForeColor = System.Drawing.Color.SlateGray;
            this.trainers.Location = new System.Drawing.Point(0, 344);
            this.trainers.Name = "trainers";
            this.trainers.Size = new System.Drawing.Size(200, 41);
            this.trainers.TabIndex = 5;
            this.trainers.Text = "TRAINERS";
            this.trainers.UseVisualStyleBackColor = true;
            this.trainers.Click += new System.EventHandler(this.trainers_Click);
            // 
            // metrics
            // 
            this.metrics.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metrics.Dock = System.Windows.Forms.DockStyle.Top;
            this.metrics.FlatAppearance.BorderSize = 0;
            this.metrics.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.metrics.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.metrics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.metrics.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metrics.ForeColor = System.Drawing.Color.SlateGray;
            this.metrics.Location = new System.Drawing.Point(0, 303);
            this.metrics.Name = "metrics";
            this.metrics.Size = new System.Drawing.Size(200, 41);
            this.metrics.TabIndex = 4;
            this.metrics.Text = "METRICS";
            this.metrics.UseVisualStyleBackColor = true;
            this.metrics.Click += new System.EventHandler(this.metrics_Click);
            // 
            // PLAN
            // 
            this.PLAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PLAN.Dock = System.Windows.Forms.DockStyle.Top;
            this.PLAN.FlatAppearance.BorderSize = 0;
            this.PLAN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.PLAN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PLAN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PLAN.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLAN.ForeColor = System.Drawing.Color.SlateGray;
            this.PLAN.Location = new System.Drawing.Point(0, 262);
            this.PLAN.Name = "PLAN";
            this.PLAN.Size = new System.Drawing.Size(200, 41);
            this.PLAN.TabIndex = 3;
            this.PLAN.Text = "WORK PLAN";
            this.PLAN.UseVisualStyleBackColor = true;
            this.PLAN.Click += new System.EventHandler(this.PLAN_Click);
            // 
            // DIET
            // 
            this.DIET.BackColor = System.Drawing.Color.DodgerBlue;
            this.DIET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DIET.Dock = System.Windows.Forms.DockStyle.Top;
            this.DIET.FlatAppearance.BorderSize = 0;
            this.DIET.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.DIET.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.DIET.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DIET.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DIET.ForeColor = System.Drawing.Color.Azure;
            this.DIET.Location = new System.Drawing.Point(0, 221);
            this.DIET.Name = "DIET";
            this.DIET.Size = new System.Drawing.Size(200, 41);
            this.DIET.TabIndex = 2;
            this.DIET.Text = "DIET";
            this.DIET.UseVisualStyleBackColor = false;
            this.DIET.Click += new System.EventHandler(this.DIET_Click);
            // 
            // dashboard
            // 
            this.dashboard.BackColor = System.Drawing.Color.Transparent;
            this.dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.dashboard.FlatAppearance.BorderSize = 0;
            this.dashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.dashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard.ForeColor = System.Drawing.Color.SlateGray;
            this.dashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard.Location = new System.Drawing.Point(0, 180);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(200, 41);
            this.dashboard.TabIndex = 1;
            this.dashboard.Text = "DASHBOARD";
            this.dashboard.UseVisualStyleBackColor = false;
            this.dashboard.Click += new System.EventHandler(this.dashboard_Click);
            // 
            // userInfo
            // 
            this.userInfo.Controls.Add(this.logo);
            this.userInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.userInfo.Location = new System.Drawing.Point(0, 0);
            this.userInfo.Name = "userInfo";
            this.userInfo.Size = new System.Drawing.Size(200, 180);
            this.userInfo.TabIndex = 0;
            // 
            // logo
            // 
            this.logo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logo.BackgroundImage")));
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logo.Location = new System.Drawing.Point(36, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(127, 128);
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            // 
            // topside
            // 
            this.topside.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.topside.Controls.Add(this.minimize);
            this.topside.Controls.Add(this.exit);
            this.topside.Dock = System.Windows.Forms.DockStyle.Top;
            this.topside.Location = new System.Drawing.Point(200, 0);
            this.topside.Name = "topside";
            this.topside.Size = new System.Drawing.Size(1012, 38);
            this.topside.TabIndex = 1;
            // 
            // minimize
            // 
            this.minimize.BackColor = System.Drawing.Color.Transparent;
            this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimize.FlatAppearance.BorderSize = 0;
            this.minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize.ForeColor = System.Drawing.Color.DimGray;
            this.minimize.Location = new System.Drawing.Point(940, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(36, 38);
            this.minimize.TabIndex = 1;
            this.minimize.Text = "-";
            this.minimize.UseVisualStyleBackColor = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.DimGray;
            this.exit.Location = new System.Drawing.Point(976, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(36, 38);
            this.exit.TabIndex = 0;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // welcome
            // 
            this.welcome.AutoSize = true;
            this.welcome.Font = new System.Drawing.Font("Cascadia Code", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome.ForeColor = System.Drawing.Color.White;
            this.welcome.Location = new System.Drawing.Point(15, 22);
            this.welcome.Name = "welcome";
            this.welcome.Size = new System.Drawing.Size(95, 35);
            this.welcome.TabIndex = 8;
            this.welcome.Text = "DIETS";
            this.welcome.Click += new System.EventHandler(this.welcome_Click);
            // 
            // addDiet
            // 
            this.addDiet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addDiet.FlatAppearance.BorderSize = 0;
            this.addDiet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.addDiet.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.addDiet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addDiet.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDiet.ForeColor = System.Drawing.Color.SlateGray;
            this.addDiet.Location = new System.Drawing.Point(1000, 62);
            this.addDiet.Name = "addDiet";
            this.addDiet.Size = new System.Drawing.Size(200, 41);
            this.addDiet.TabIndex = 14;
            this.addDiet.Text = "ADD DIET";
            this.addDiet.UseVisualStyleBackColor = true;
            this.addDiet.Click += new System.EventHandler(this.addDiet_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.prompt);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.TrainersPlans);
            this.panel1.Controls.Add(this.memberPlans);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.report);
            this.panel1.Controls.Add(this.filter);
            this.panel1.Controls.Add(this.welcome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(200, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 631);
            this.panel1.TabIndex = 15;
            // 
            // prompt
            // 
            this.prompt.AutoSize = true;
            this.prompt.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prompt.ForeColor = System.Drawing.Color.Crimson;
            this.prompt.Location = new System.Drawing.Point(244, 39);
            this.prompt.Name = "prompt";
            this.prompt.Size = new System.Drawing.Size(0, 15);
            this.prompt.TabIndex = 28;
            this.prompt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(0, 245);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 207);
            this.panel2.TabIndex = 27;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.AutoSize = true;
            this.panel3.Controls.Add(this.dietTable);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(539, 207);
            this.panel3.TabIndex = 27;
            // 
            // dietTable
            // 
            this.dietTable.AutoScroll = true;
            this.dietTable.AutoSize = true;
            this.dietTable.ColumnCount = 6;
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.dietTable.Controls.Add(this.label3, 3, 0);
            this.dietTable.Controls.Add(this.label4, 2, 0);
            this.dietTable.Controls.Add(this.label5, 1, 0);
            this.dietTable.Controls.Add(this.label6, 0, 0);
            this.dietTable.Controls.Add(this.label7, 4, 0);
            this.dietTable.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dietTable.Location = new System.Drawing.Point(0, 0);
            this.dietTable.Name = "dietTable";
            this.dietTable.RowCount = 2;
            this.dietTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.dietTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.dietTable.Size = new System.Drawing.Size(452, 69);
            this.dietTable.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(186, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 21);
            this.label3.TabIndex = 14;
            this.label3.Text = "Amount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(89, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 21);
            this.label4.TabIndex = 14;
            this.label4.Text = "Nutrition";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(37, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 21);
            this.label5.TabIndex = 14;
            this.label5.Text = "Meal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 21);
            this.label6.TabIndex = 14;
            this.label6.Text = "ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(256, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 21);
            this.label7.TabIndex = 15;
            this.label7.Text = "Allergen";
            // 
            // TrainersPlans
            // 
            this.TrainersPlans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.TrainersPlans.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrainersPlans.ForeColor = System.Drawing.Color.White;
            this.TrainersPlans.FormattingEnabled = true;
            this.TrainersPlans.Items.AddRange(new object[] {
            "Allergen",
            "Nutrients"});
            this.TrainersPlans.Location = new System.Drawing.Point(21, 95);
            this.TrainersPlans.Name = "TrainersPlans";
            this.TrainersPlans.Size = new System.Drawing.Size(124, 23);
            this.TrainersPlans.TabIndex = 26;
            // 
            // memberPlans
            // 
            this.memberPlans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.memberPlans.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memberPlans.ForeColor = System.Drawing.Color.White;
            this.memberPlans.FormattingEnabled = true;
            this.memberPlans.Items.AddRange(new object[] {
            "Self",
            "Members",
            "Trainers"});
            this.memberPlans.Location = new System.Drawing.Point(24, 162);
            this.memberPlans.Name = "memberPlans";
            this.memberPlans.Size = new System.Drawing.Size(121, 23);
            this.memberPlans.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(21, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 15);
            this.label9.TabIndex = 24;
            this.label9.Text = "Filter";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(21, 142);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 15);
            this.label8.TabIndex = 23;
            this.label8.Text = "Filter";
            // 
            // report
            // 
            this.report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.report.FlatAppearance.BorderSize = 0;
            this.report.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.report.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.report.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report.ForeColor = System.Drawing.Color.SlateGray;
            this.report.Location = new System.Drawing.Point(367, 150);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(138, 52);
            this.report.TabIndex = 20;
            this.report.Text = "Generate Report";
            this.report.UseVisualStyleBackColor = true;
            this.report.Click += new System.EventHandler(this.report_Click);
            // 
            // filter
            // 
            this.filter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.filter.FlatAppearance.BorderSize = 0;
            this.filter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.filter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filter.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filter.ForeColor = System.Drawing.Color.SlateGray;
            this.filter.Location = new System.Drawing.Point(367, 95);
            this.filter.Name = "filter";
            this.filter.Size = new System.Drawing.Size(138, 41);
            this.filter.TabIndex = 19;
            this.filter.Text = "Filter";
            this.filter.UseVisualStyleBackColor = true;
            this.filter.Click += new System.EventHandler(this.filter_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(742, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 15);
            this.label10.TabIndex = 22;
            this.label10.Text = "Nutrition";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(868, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 15);
            this.label11.TabIndex = 24;
            this.label11.Text = "Nutrition";
            // 
            // guideline
            // 
            this.guideline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.guideline.ForeColor = System.Drawing.Color.White;
            this.guideline.Location = new System.Drawing.Point(748, 301);
            this.guideline.Name = "guideline";
            this.guideline.Size = new System.Drawing.Size(247, 20);
            this.guideline.TabIndex = 25;
            this.guideline.TextChanged += new System.EventHandler(this.guideline_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(872, 165);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 15);
            this.label12.TabIndex = 26;
            this.label12.Text = "Objective";
            // 
            // nutri1
            // 
            this.nutri1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.nutri1.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nutri1.ForeColor = System.Drawing.Color.White;
            this.nutri1.FormattingEnabled = true;
            this.nutri1.Items.AddRange(new object[] {
            "Trainers"});
            this.nutri1.Location = new System.Drawing.Point(745, 124);
            this.nutri1.Name = "nutri1";
            this.nutri1.Size = new System.Drawing.Size(121, 23);
            this.nutri1.TabIndex = 27;
            // 
            // nutri2
            // 
            this.nutri2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.nutri2.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nutri2.ForeColor = System.Drawing.Color.White;
            this.nutri2.FormattingEnabled = true;
            this.nutri2.Items.AddRange(new object[] {
            "Trainers"});
            this.nutri2.Location = new System.Drawing.Point(871, 124);
            this.nutri2.Name = "nutri2";
            this.nutri2.Size = new System.Drawing.Size(121, 23);
            this.nutri2.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(745, 165);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 15);
            this.label13.TabIndex = 29;
            this.label13.Text = "Diet Type";
            // 
            // dietType
            // 
            this.dietType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.dietType.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dietType.ForeColor = System.Drawing.Color.White;
            this.dietType.FormattingEnabled = true;
            this.dietType.Items.AddRange(new object[] {
            "Breakfast",
            "Lunch",
            "Snack",
            "Dinner"});
            this.dietType.Location = new System.Drawing.Point(745, 183);
            this.dietType.Name = "dietType";
            this.dietType.Size = new System.Drawing.Size(121, 23);
            this.dietType.TabIndex = 30;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.comboBox1.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Muscle Gain",
            "Weight Loss",
            "General Health"});
            this.comboBox1.Location = new System.Drawing.Point(871, 183);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 31;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // difficulty
            // 
            this.difficulty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.difficulty.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.difficulty.ForeColor = System.Drawing.Color.White;
            this.difficulty.FormattingEnabled = true;
            this.difficulty.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.difficulty.Location = new System.Drawing.Point(745, 239);
            this.difficulty.Name = "difficulty";
            this.difficulty.Size = new System.Drawing.Size(121, 23);
            this.difficulty.TabIndex = 32;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(745, 221);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 15);
            this.label14.TabIndex = 33;
            this.label14.Text = "Difficulty";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(745, 283);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 15);
            this.label15.TabIndex = 34;
            this.label15.Text = "Guidlines";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // success
            // 
            this.success.AutoSize = true;
            this.success.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.success.ForeColor = System.Drawing.Color.LawnGreen;
            this.success.Location = new System.Drawing.Point(919, 370);
            this.success.Name = "success";
            this.success.Size = new System.Drawing.Size(0, 15);
            this.success.TabIndex = 35;
            // 
            // setCurr
            // 
            this.setCurr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.setCurr.FlatAppearance.BorderSize = 0;
            this.setCurr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.setCurr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.setCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.setCurr.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setCurr.ForeColor = System.Drawing.Color.SlateGray;
            this.setCurr.Location = new System.Drawing.Point(1000, 410);
            this.setCurr.Name = "setCurr";
            this.setCurr.Size = new System.Drawing.Size(200, 41);
            this.setCurr.TabIndex = 36;
            this.setCurr.Text = "Set Current";
            this.setCurr.UseVisualStyleBackColor = true;
            this.setCurr.Click += new System.EventHandler(this.button1_Click);
            // 
            // dietSelectList
            // 
            this.dietSelectList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.dietSelectList.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dietSelectList.ForeColor = System.Drawing.Color.White;
            this.dietSelectList.FormattingEnabled = true;
            this.dietSelectList.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.dietSelectList.Location = new System.Drawing.Point(745, 422);
            this.dietSelectList.Name = "dietSelectList";
            this.dietSelectList.Size = new System.Drawing.Size(121, 23);
            this.dietSelectList.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(745, 404);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 38;
            this.label1.Text = "Set Diet";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // MemberDiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.ClientSize = new System.Drawing.Size(1212, 669);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dietSelectList);
            this.Controls.Add(this.setCurr);
            this.Controls.Add(this.success);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.difficulty);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dietType);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.nutri2);
            this.Controls.Add(this.nutri1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.guideline);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.addDiet);
            this.Controls.Add(this.topside);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MemberDiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberDash";
            this.menu.ResumeLayout(false);
            this.userInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.topside.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.dietTable.ResumeLayout(false);
            this.dietTable.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public void MenuFormat()
        {
            menu.BackColor = Color.FromArgb(11, 35, 61);
            menu.Dock = System.Windows.Forms.DockStyle.Left;
        }
        public void TopFormat()
        {
            topside.BackColor = Color.LavenderBlush;
            topside.Dock = System.Windows.Forms.DockStyle.Top;
        }
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Panel topside;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel userInfo;
        private System.Windows.Forms.Button dashboard;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button DIET;
        private System.Windows.Forms.Button metrics;
        private System.Windows.Forms.Button PLAN;
        private System.Windows.Forms.Button trainers;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label welcome;
        private System.Windows.Forms.Button addDiet;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button report;
        private System.Windows.Forms.Button filter;
        private System.Windows.Forms.TableLayoutPanel dietTable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox guideline;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox memberPlans;
        private System.Windows.Forms.ComboBox TrainersPlans;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox nutri1;
        private System.Windows.Forms.ComboBox nutri2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox dietType;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox difficulty;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label prompt;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label success;
        private System.Windows.Forms.Button setCurr;
        private System.Windows.Forms.ComboBox dietSelectList;
        private System.Windows.Forms.Label label1;
    }
}