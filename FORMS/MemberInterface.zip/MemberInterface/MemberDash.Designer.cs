﻿using System.Drawing;

namespace TrainerInterface
{
    partial class MemberDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberDash));
            this.menu = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.trainers = new System.Windows.Forms.Button();
            this.metrics = new System.Windows.Forms.Button();
            this.PLAN = new System.Windows.Forms.Button();
            this.DIET = new System.Windows.Forms.Button();
            this.dashboard = new System.Windows.Forms.Button();
            this.userInfo = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.topside = new System.Windows.Forms.Panel();
            this.minimize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.change = new System.Windows.Forms.Button();
            this.welcome = new System.Windows.Forms.Label();
            this.usernamelbl = new System.Windows.Forms.Label();
            this.currentplan = new System.Windows.Forms.Label();
            this.currentTrainer = new System.Windows.Forms.Label();
            this.currentWP = new System.Windows.Forms.TableLayoutPanel();
            this.numReps = new System.Windows.Forms.Label();
            this.Numsets = new System.Windows.Forms.Label();
            this.exName = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.exp = new System.Windows.Forms.Label();
            this.dashGym = new System.Windows.Forms.Label();
            this.dashTrain = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.nameChange = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.passChange = new System.Windows.Forms.TextBox();
            this.emailChange = new System.Windows.Forms.TextBox();
            this.nmCH = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.menu.SuspendLayout();
            this.userInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.topside.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.currentWP.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.menu.Controls.Add(this.logout);
            this.menu.Controls.Add(this.trainers);
            this.menu.Controls.Add(this.metrics);
            this.menu.Controls.Add(this.PLAN);
            this.menu.Controls.Add(this.DIET);
            this.menu.Controls.Add(this.dashboard);
            this.menu.Controls.Add(this.userInfo);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(200, 669);
            this.menu.TabIndex = 0;
            this.menu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // logout
            // 
            this.logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleVioletRed;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.SlateGray;
            this.logout.Location = new System.Drawing.Point(0, 628);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(200, 41);
            this.logout.TabIndex = 6;
            this.logout.Text = "LOGOUT";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // trainers
            // 
            this.trainers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trainers.Dock = System.Windows.Forms.DockStyle.Top;
            this.trainers.FlatAppearance.BorderSize = 0;
            this.trainers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.trainers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.trainers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trainers.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainers.ForeColor = System.Drawing.Color.SlateGray;
            this.trainers.Location = new System.Drawing.Point(0, 344);
            this.trainers.Name = "trainers";
            this.trainers.Size = new System.Drawing.Size(200, 41);
            this.trainers.TabIndex = 5;
            this.trainers.Text = "TRAINERS";
            this.trainers.UseVisualStyleBackColor = true;
            this.trainers.Click += new System.EventHandler(this.trainers_Click);
            // 
            // metrics
            // 
            this.metrics.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metrics.Dock = System.Windows.Forms.DockStyle.Top;
            this.metrics.FlatAppearance.BorderSize = 0;
            this.metrics.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.metrics.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.metrics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.metrics.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metrics.ForeColor = System.Drawing.Color.SlateGray;
            this.metrics.Location = new System.Drawing.Point(0, 303);
            this.metrics.Name = "metrics";
            this.metrics.Size = new System.Drawing.Size(200, 41);
            this.metrics.TabIndex = 4;
            this.metrics.Text = "METRICS";
            this.metrics.UseVisualStyleBackColor = true;
            this.metrics.Click += new System.EventHandler(this.metrics_Click);
            // 
            // PLAN
            // 
            this.PLAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PLAN.Dock = System.Windows.Forms.DockStyle.Top;
            this.PLAN.FlatAppearance.BorderSize = 0;
            this.PLAN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.PLAN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PLAN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PLAN.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLAN.ForeColor = System.Drawing.Color.SlateGray;
            this.PLAN.Location = new System.Drawing.Point(0, 262);
            this.PLAN.Name = "PLAN";
            this.PLAN.Size = new System.Drawing.Size(200, 41);
            this.PLAN.TabIndex = 3;
            this.PLAN.Text = "WORK PLAN";
            this.PLAN.UseVisualStyleBackColor = true;
            this.PLAN.Click += new System.EventHandler(this.PLAN_Click);
            // 
            // DIET
            // 
            this.DIET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DIET.Dock = System.Windows.Forms.DockStyle.Top;
            this.DIET.FlatAppearance.BorderSize = 0;
            this.DIET.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.DIET.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.DIET.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DIET.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DIET.ForeColor = System.Drawing.Color.SlateGray;
            this.DIET.Location = new System.Drawing.Point(0, 221);
            this.DIET.Name = "DIET";
            this.DIET.Size = new System.Drawing.Size(200, 41);
            this.DIET.TabIndex = 2;
            this.DIET.Text = "DIET";
            this.DIET.UseVisualStyleBackColor = true;
            this.DIET.Click += new System.EventHandler(this.DIET_Click);
            // 
            // dashboard
            // 
            this.dashboard.BackColor = System.Drawing.Color.DodgerBlue;
            this.dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.dashboard.FlatAppearance.BorderSize = 0;
            this.dashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.dashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard.ForeColor = System.Drawing.Color.White;
            this.dashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard.Location = new System.Drawing.Point(0, 180);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(200, 41);
            this.dashboard.TabIndex = 1;
            this.dashboard.Text = "DASHBOARD";
            this.dashboard.UseVisualStyleBackColor = false;
            // 
            // userInfo
            // 
            this.userInfo.Controls.Add(this.logo);
            this.userInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.userInfo.Location = new System.Drawing.Point(0, 0);
            this.userInfo.Name = "userInfo";
            this.userInfo.Size = new System.Drawing.Size(200, 180);
            this.userInfo.TabIndex = 0;
            // 
            // logo
            // 
            this.logo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logo.BackgroundImage")));
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logo.Location = new System.Drawing.Point(36, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(127, 128);
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            // 
            // topside
            // 
            this.topside.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.topside.Controls.Add(this.minimize);
            this.topside.Controls.Add(this.exit);
            this.topside.Dock = System.Windows.Forms.DockStyle.Top;
            this.topside.Location = new System.Drawing.Point(200, 0);
            this.topside.Name = "topside";
            this.topside.Size = new System.Drawing.Size(1012, 38);
            this.topside.TabIndex = 1;
            // 
            // minimize
            // 
            this.minimize.BackColor = System.Drawing.Color.Transparent;
            this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimize.FlatAppearance.BorderSize = 0;
            this.minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize.ForeColor = System.Drawing.Color.DimGray;
            this.minimize.Location = new System.Drawing.Point(940, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(36, 38);
            this.minimize.TabIndex = 1;
            this.minimize.Text = "-";
            this.minimize.UseVisualStyleBackColor = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.DimGray;
            this.exit.Location = new System.Drawing.Point(976, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(36, 38);
            this.exit.TabIndex = 0;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(996, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(204, 246);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // change
            // 
            this.change.Cursor = System.Windows.Forms.Cursors.Hand;
            this.change.FlatAppearance.BorderSize = 0;
            this.change.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.change.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.change.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.change.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.change.ForeColor = System.Drawing.Color.SlateGray;
            this.change.Location = new System.Drawing.Point(996, 303);
            this.change.Name = "change";
            this.change.Size = new System.Drawing.Size(200, 41);
            this.change.TabIndex = 7;
            this.change.Text = "CHANGE DETAILS";
            this.change.UseVisualStyleBackColor = true;
            this.change.Click += new System.EventHandler(this.change_Click);
            // 
            // welcome
            // 
            this.welcome.AutoSize = true;
            this.welcome.Font = new System.Drawing.Font("Cascadia Code", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome.ForeColor = System.Drawing.Color.White;
            this.welcome.Location = new System.Drawing.Point(215, 60);
            this.welcome.Name = "welcome";
            this.welcome.Size = new System.Drawing.Size(415, 35);
            this.welcome.TabIndex = 8;
            this.welcome.Text = "WELCOME TO YOUR DASHBOARD";
            // 
            // usernamelbl
            // 
            this.usernamelbl.AutoSize = true;
            this.usernamelbl.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernamelbl.ForeColor = System.Drawing.Color.White;
            this.usernamelbl.Location = new System.Drawing.Point(216, 112);
            this.usernamelbl.Name = "usernamelbl";
            this.usernamelbl.Size = new System.Drawing.Size(120, 28);
            this.usernamelbl.TabIndex = 9;
            this.usernamelbl.Text = "USER NAME";
            // 
            // currentplan
            // 
            this.currentplan.AutoSize = true;
            this.currentplan.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentplan.ForeColor = System.Drawing.Color.White;
            this.currentplan.Location = new System.Drawing.Point(218, 221);
            this.currentplan.Name = "currentplan";
            this.currentplan.Size = new System.Drawing.Size(156, 28);
            this.currentplan.TabIndex = 10;
            this.currentplan.Text = "CURRENT PLAN";
            // 
            // currentTrainer
            // 
            this.currentTrainer.AutoSize = true;
            this.currentTrainer.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentTrainer.ForeColor = System.Drawing.Color.White;
            this.currentTrainer.Location = new System.Drawing.Point(216, 383);
            this.currentTrainer.Name = "currentTrainer";
            this.currentTrainer.Size = new System.Drawing.Size(192, 28);
            this.currentTrainer.TabIndex = 11;
            this.currentTrainer.Text = "CURRENT TRAINER";
            // 
            // currentWP
            // 
            this.currentWP.AutoScroll = true;
            this.currentWP.AutoSize = true;
            this.currentWP.ColumnCount = 3;
            this.currentWP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.currentWP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.currentWP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.currentWP.Controls.Add(this.numReps, 2, 0);
            this.currentWP.Controls.Add(this.Numsets, 1, 0);
            this.currentWP.Controls.Add(this.exName, 0, 0);
            this.currentWP.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentWP.Location = new System.Drawing.Point(0, 3);
            this.currentWP.Name = "currentWP";
            this.currentWP.RowCount = 2;
            this.currentWP.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.currentWP.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.currentWP.Size = new System.Drawing.Size(466, 47);
            this.currentWP.TabIndex = 12;
            this.currentWP.Paint += new System.Windows.Forms.PaintEventHandler(this.currentWP_Paint);
            // 
            // numReps
            // 
            this.numReps.AutoSize = true;
            this.numReps.ForeColor = System.Drawing.Color.White;
            this.numReps.Location = new System.Drawing.Point(152, 0);
            this.numReps.Name = "numReps";
            this.numReps.Size = new System.Drawing.Size(46, 21);
            this.numReps.TabIndex = 14;
            this.numReps.Text = "Reps";
            // 
            // Numsets
            // 
            this.Numsets.AutoSize = true;
            this.Numsets.Dock = System.Windows.Forms.DockStyle.Left;
            this.Numsets.ForeColor = System.Drawing.Color.White;
            this.Numsets.Location = new System.Drawing.Point(100, 0);
            this.Numsets.Name = "Numsets";
            this.Numsets.Size = new System.Drawing.Size(46, 21);
            this.Numsets.TabIndex = 14;
            this.Numsets.Text = "Sets";
            // 
            // exName
            // 
            this.exName.AutoSize = true;
            this.exName.Dock = System.Windows.Forms.DockStyle.Left;
            this.exName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.exName.Location = new System.Drawing.Point(3, 0);
            this.exName.Name = "exName";
            this.exName.Size = new System.Drawing.Size(91, 21);
            this.exName.TabIndex = 14;
            this.exName.Text = "Excercise";
            this.exName.Click += new System.EventHandler(this.label1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.exp, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.dashGym, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dashTrain, 0, 0);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(463, 69);
            this.tableLayoutPanel1.TabIndex = 13;
            // 
            // exp
            // 
            this.exp.AutoSize = true;
            this.exp.ForeColor = System.Drawing.Color.White;
            this.exp.Location = new System.Drawing.Point(98, 0);
            this.exp.Name = "exp";
            this.exp.Size = new System.Drawing.Size(100, 21);
            this.exp.TabIndex = 14;
            this.exp.Text = "Experience";
            // 
            // dashGym
            // 
            this.dashGym.AutoSize = true;
            this.dashGym.ForeColor = System.Drawing.Color.White;
            this.dashGym.Location = new System.Drawing.Point(55, 0);
            this.dashGym.Name = "dashGym";
            this.dashGym.Size = new System.Drawing.Size(37, 21);
            this.dashGym.TabIndex = 14;
            this.dashGym.Text = "Gym";
            // 
            // dashTrain
            // 
            this.dashTrain.AutoSize = true;
            this.dashTrain.ForeColor = System.Drawing.Color.White;
            this.dashTrain.Location = new System.Drawing.Point(3, 0);
            this.dashTrain.Name = "dashTrain";
            this.dashTrain.Size = new System.Drawing.Size(46, 21);
            this.dashTrain.TabIndex = 14;
            this.dashTrain.Text = "Name";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(221, 262);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(466, 100);
            this.panel1.TabIndex = 14;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.AutoSize = true;
            this.panel2.Controls.Add(this.currentWP);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(466, 100);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(221, 423);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(466, 101);
            this.panel3.TabIndex = 15;
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.AutoSize = true;
            this.panel4.Controls.Add(this.tableLayoutPanel1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(466, 101);
            this.panel4.TabIndex = 16;
            // 
            // nameChange
            // 
            this.nameChange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(94)))));
            this.nameChange.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameChange.Location = new System.Drawing.Point(1045, 383);
            this.nameChange.Name = "nameChange";
            this.nameChange.Size = new System.Drawing.Size(100, 20);
            this.nameChange.TabIndex = 16;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // passChange
            // 
            this.passChange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(94)))));
            this.passChange.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passChange.ForeColor = System.Drawing.Color.White;
            this.passChange.Location = new System.Drawing.Point(994, 426);
            this.passChange.Name = "passChange";
            this.passChange.Size = new System.Drawing.Size(100, 20);
            this.passChange.TabIndex = 18;
            this.passChange.TextChanged += new System.EventHandler(this.passChange_TextChanged);
            // 
            // emailChange
            // 
            this.emailChange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(94)))));
            this.emailChange.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailChange.Location = new System.Drawing.Point(1100, 426);
            this.emailChange.Name = "emailChange";
            this.emailChange.Size = new System.Drawing.Size(100, 20);
            this.emailChange.TabIndex = 19;
            // 
            // nmCH
            // 
            this.nmCH.AutoSize = true;
            this.nmCH.Font = new System.Drawing.Font("Cascadia Code SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmCH.ForeColor = System.Drawing.Color.Snow;
            this.nmCH.Location = new System.Drawing.Point(1042, 365);
            this.nmCH.Name = "nmCH";
            this.nmCH.Size = new System.Drawing.Size(31, 15);
            this.nmCH.TabIndex = 20;
            this.nmCH.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Code SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Snow;
            this.label1.Location = new System.Drawing.Point(991, 408);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cascadia Code SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Snow;
            this.label2.Location = new System.Drawing.Point(1097, 408);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cascadia Code SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(993, 477);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 15);
            this.label3.TabIndex = 23;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // MemberDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.ClientSize = new System.Drawing.Size(1212, 669);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nmCH);
            this.Controls.Add(this.emailChange);
            this.Controls.Add(this.passChange);
            this.Controls.Add(this.nameChange);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.currentTrainer);
            this.Controls.Add(this.currentplan);
            this.Controls.Add(this.usernamelbl);
            this.Controls.Add(this.welcome);
            this.Controls.Add(this.change);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.topside);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MemberDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberDash";
            this.menu.ResumeLayout(false);
            this.userInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.topside.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.currentWP.ResumeLayout(false);
            this.currentWP.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public void MenuFormat()
        {
            menu.BackColor = Color.FromArgb(11, 35, 61);
            menu.Dock = System.Windows.Forms.DockStyle.Left;
        }
        public void TopFormat()
        {
            topside.BackColor = Color.LavenderBlush;
            topside.Dock = System.Windows.Forms.DockStyle.Top;
        }
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Panel topside;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel userInfo;
        private System.Windows.Forms.Button dashboard;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button DIET;
        private System.Windows.Forms.Button metrics;
        private System.Windows.Forms.Button PLAN;
        private System.Windows.Forms.Button trainers;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button change;
        private System.Windows.Forms.Label welcome;
        private System.Windows.Forms.Label usernamelbl;
        private System.Windows.Forms.Label currentplan;
        private System.Windows.Forms.Label currentTrainer;
        private System.Windows.Forms.TableLayoutPanel currentWP;
        private System.Windows.Forms.Label exName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label Numsets;
        private System.Windows.Forms.Label numReps;
        private System.Windows.Forms.Label dashGym;
        private System.Windows.Forms.Label dashTrain;
        private System.Windows.Forms.Label exp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox nameChange;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox passChange;
        private System.Windows.Forms.TextBox emailChange;
        private System.Windows.Forms.Label nmCH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}