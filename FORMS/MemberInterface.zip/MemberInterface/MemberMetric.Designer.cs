﻿using System.Drawing;

namespace TrainerInterface
{
    partial class MemberMetric
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MemberMetric));
            this.menu = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.trainers = new System.Windows.Forms.Button();
            this.metrics = new System.Windows.Forms.Button();
            this.PLAN = new System.Windows.Forms.Button();
            this.DIET = new System.Windows.Forms.Button();
            this.dashboard = new System.Windows.Forms.Button();
            this.userInfo = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.PictureBox();
            this.topside = new System.Windows.Forms.Panel();
            this.minimize = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.welcome = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.trainerPrompt = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TrainerSelection = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chooseTrainer = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Rating = new System.Windows.Forms.ComboBox();
            this.SelectTrainer = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.report = new System.Windows.Forms.Button();
            this.filter = new System.Windows.Forms.Button();
            this.metricRight = new System.Windows.Forms.Panel();
            this.gymPrompt = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.chooseGym = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gymRating = new System.Windows.Forms.ComboBox();
            this.SelectGym = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.report2 = new System.Windows.Forms.Button();
            this.filter2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.menu.SuspendLayout();
            this.userInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.topside.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.metricRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.menu.Controls.Add(this.logout);
            this.menu.Controls.Add(this.trainers);
            this.menu.Controls.Add(this.metrics);
            this.menu.Controls.Add(this.PLAN);
            this.menu.Controls.Add(this.DIET);
            this.menu.Controls.Add(this.dashboard);
            this.menu.Controls.Add(this.userInfo);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(200, 669);
            this.menu.TabIndex = 0;
            this.menu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // logout
            // 
            this.logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.logout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.PaleVioletRed;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.ForeColor = System.Drawing.Color.SlateGray;
            this.logout.Location = new System.Drawing.Point(0, 628);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(200, 41);
            this.logout.TabIndex = 6;
            this.logout.Text = "LOGOUT";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // trainers
            // 
            this.trainers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.trainers.Dock = System.Windows.Forms.DockStyle.Top;
            this.trainers.FlatAppearance.BorderSize = 0;
            this.trainers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.trainers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.trainers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trainers.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainers.ForeColor = System.Drawing.Color.SlateGray;
            this.trainers.Location = new System.Drawing.Point(0, 344);
            this.trainers.Name = "trainers";
            this.trainers.Size = new System.Drawing.Size(200, 41);
            this.trainers.TabIndex = 5;
            this.trainers.Text = "TRAINERS";
            this.trainers.UseVisualStyleBackColor = true;
            this.trainers.Click += new System.EventHandler(this.trainers_Click);
            // 
            // metrics
            // 
            this.metrics.BackColor = System.Drawing.Color.DodgerBlue;
            this.metrics.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metrics.Dock = System.Windows.Forms.DockStyle.Top;
            this.metrics.FlatAppearance.BorderSize = 0;
            this.metrics.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.metrics.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.metrics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.metrics.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metrics.ForeColor = System.Drawing.Color.Azure;
            this.metrics.Location = new System.Drawing.Point(0, 303);
            this.metrics.Name = "metrics";
            this.metrics.Size = new System.Drawing.Size(200, 41);
            this.metrics.TabIndex = 4;
            this.metrics.Text = "METRICS";
            this.metrics.UseVisualStyleBackColor = false;
            // 
            // PLAN
            // 
            this.PLAN.BackColor = System.Drawing.Color.Transparent;
            this.PLAN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PLAN.Dock = System.Windows.Forms.DockStyle.Top;
            this.PLAN.FlatAppearance.BorderSize = 0;
            this.PLAN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.PLAN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.PLAN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PLAN.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLAN.ForeColor = System.Drawing.Color.SlateGray;
            this.PLAN.Location = new System.Drawing.Point(0, 262);
            this.PLAN.Name = "PLAN";
            this.PLAN.Size = new System.Drawing.Size(200, 41);
            this.PLAN.TabIndex = 3;
            this.PLAN.Text = "WORK PLAN";
            this.PLAN.UseVisualStyleBackColor = false;
            this.PLAN.Click += new System.EventHandler(this.PLAN_Click);
            // 
            // DIET
            // 
            this.DIET.BackColor = System.Drawing.Color.Transparent;
            this.DIET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DIET.Dock = System.Windows.Forms.DockStyle.Top;
            this.DIET.FlatAppearance.BorderSize = 0;
            this.DIET.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.DIET.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.DIET.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DIET.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DIET.ForeColor = System.Drawing.Color.SlateGray;
            this.DIET.Location = new System.Drawing.Point(0, 221);
            this.DIET.Name = "DIET";
            this.DIET.Size = new System.Drawing.Size(200, 41);
            this.DIET.TabIndex = 2;
            this.DIET.Text = "DIET";
            this.DIET.UseVisualStyleBackColor = false;
            this.DIET.Click += new System.EventHandler(this.DIET_Click);
            // 
            // dashboard
            // 
            this.dashboard.BackColor = System.Drawing.Color.Transparent;
            this.dashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.dashboard.FlatAppearance.BorderSize = 0;
            this.dashboard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.dashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard.ForeColor = System.Drawing.Color.SlateGray;
            this.dashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard.Location = new System.Drawing.Point(0, 180);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(200, 41);
            this.dashboard.TabIndex = 1;
            this.dashboard.Text = "DASHBOARD";
            this.dashboard.UseVisualStyleBackColor = false;
            this.dashboard.Click += new System.EventHandler(this.dashboard_Click);
            // 
            // userInfo
            // 
            this.userInfo.Controls.Add(this.logo);
            this.userInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.userInfo.Location = new System.Drawing.Point(0, 0);
            this.userInfo.Name = "userInfo";
            this.userInfo.Size = new System.Drawing.Size(200, 180);
            this.userInfo.TabIndex = 0;
            // 
            // logo
            // 
            this.logo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("logo.BackgroundImage")));
            this.logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.logo.Location = new System.Drawing.Point(36, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(127, 128);
            this.logo.TabIndex = 0;
            this.logo.TabStop = false;
            // 
            // topside
            // 
            this.topside.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(22)))), ((int)(((byte)(46)))));
            this.topside.Controls.Add(this.minimize);
            this.topside.Controls.Add(this.exit);
            this.topside.Dock = System.Windows.Forms.DockStyle.Top;
            this.topside.Location = new System.Drawing.Point(200, 0);
            this.topside.Name = "topside";
            this.topside.Size = new System.Drawing.Size(1012, 38);
            this.topside.TabIndex = 1;
            // 
            // minimize
            // 
            this.minimize.BackColor = System.Drawing.Color.Transparent;
            this.minimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimize.FlatAppearance.BorderSize = 0;
            this.minimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimize.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimize.ForeColor = System.Drawing.Color.DimGray;
            this.minimize.Location = new System.Drawing.Point(940, 0);
            this.minimize.Name = "minimize";
            this.minimize.Size = new System.Drawing.Size(36, 38);
            this.minimize.TabIndex = 1;
            this.minimize.Text = "-";
            this.minimize.UseVisualStyleBackColor = false;
            this.minimize.Click += new System.EventHandler(this.minimize_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.Dock = System.Windows.Forms.DockStyle.Right;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.Font = new System.Drawing.Font("Cascadia Code", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.DimGray;
            this.exit.Location = new System.Drawing.Point(976, 0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(36, 38);
            this.exit.TabIndex = 0;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // welcome
            // 
            this.welcome.AutoSize = true;
            this.welcome.Font = new System.Drawing.Font("Cascadia Code", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcome.ForeColor = System.Drawing.Color.White;
            this.welcome.Location = new System.Drawing.Point(15, 22);
            this.welcome.Name = "welcome";
            this.welcome.Size = new System.Drawing.Size(127, 35);
            this.welcome.TabIndex = 8;
            this.welcome.Text = "METRICS";
            this.welcome.Click += new System.EventHandler(this.welcome_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.chooseTrainer);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Rating);
            this.panel1.Controls.Add(this.SelectTrainer);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.report);
            this.panel1.Controls.Add(this.filter);
            this.panel1.Controls.Add(this.welcome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(200, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(517, 631);
            this.panel1.TabIndex = 15;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.panel2.Controls.Add(this.trainerPrompt);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.richTextBox1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.TrainerSelection);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.comboBox3);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(517, 631);
            this.panel2.TabIndex = 32;
            // 
            // trainerPrompt
            // 
            this.trainerPrompt.AutoSize = true;
            this.trainerPrompt.ForeColor = System.Drawing.Color.Crimson;
            this.trainerPrompt.Location = new System.Drawing.Point(268, 57);
            this.trainerPrompt.Name = "trainerPrompt";
            this.trainerPrompt.Size = new System.Drawing.Size(0, 13);
            this.trainerPrompt.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(18, 378);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 15);
            this.label14.TabIndex = 34;
            this.label14.Text = "Review";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.richTextBox1.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.White;
            this.richTextBox1.Location = new System.Drawing.Point(21, 396);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(219, 96);
            this.richTextBox1.TabIndex = 32;
            this.richTextBox1.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(18, 278);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 15);
            this.label8.TabIndex = 31;
            this.label8.Text = "Trainer";
            // 
            // TrainerSelection
            // 
            this.TrainerSelection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.TrainerSelection.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrainerSelection.ForeColor = System.Drawing.Color.White;
            this.TrainerSelection.FormattingEnabled = true;
            this.TrainerSelection.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.TrainerSelection.Location = new System.Drawing.Point(21, 296);
            this.TrainerSelection.Name = "TrainerSelection";
            this.TrainerSelection.Size = new System.Drawing.Size(124, 23);
            this.TrainerSelection.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(18, 195);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 15);
            this.label9.TabIndex = 29;
            this.label9.Text = "Rating";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.comboBox2.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox2.Location = new System.Drawing.Point(21, 213);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(124, 23);
            this.comboBox2.TabIndex = 28;
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.comboBox3.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.ForeColor = System.Drawing.Color.White;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Your Trainers",
            "Gym Trainers"});
            this.comboBox3.Location = new System.Drawing.Point(20, 155);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(124, 23);
            this.comboBox3.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(18, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 15);
            this.label10.TabIndex = 25;
            this.label10.Text = "Filter";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(15, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 28);
            this.label11.TabIndex = 21;
            this.label11.Text = "TRAINER";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.SlateGray;
            this.button1.Location = new System.Drawing.Point(367, 195);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 52);
            this.button1.TabIndex = 20;
            this.button1.Text = "Add Review";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.SlateGray;
            this.button2.Location = new System.Drawing.Point(367, 142);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 41);
            this.button2.TabIndex = 19;
            this.button2.Text = "Filter";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Cascadia Code", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(15, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 35);
            this.label12.TabIndex = 8;
            this.label12.Text = "METRICS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(18, 278);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 15);
            this.label6.TabIndex = 31;
            this.label6.Text = "Rating";
            // 
            // chooseTrainer
            // 
            this.chooseTrainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.chooseTrainer.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseTrainer.ForeColor = System.Drawing.Color.White;
            this.chooseTrainer.FormattingEnabled = true;
            this.chooseTrainer.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.chooseTrainer.Location = new System.Drawing.Point(21, 296);
            this.chooseTrainer.Name = "chooseTrainer";
            this.chooseTrainer.Size = new System.Drawing.Size(124, 23);
            this.chooseTrainer.TabIndex = 30;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(18, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 29;
            this.label3.Text = "Rating";
            // 
            // Rating
            // 
            this.Rating.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.Rating.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rating.ForeColor = System.Drawing.Color.White;
            this.Rating.FormattingEnabled = true;
            this.Rating.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.Rating.Location = new System.Drawing.Point(21, 213);
            this.Rating.Name = "Rating";
            this.Rating.Size = new System.Drawing.Size(124, 23);
            this.Rating.TabIndex = 28;
            // 
            // SelectTrainer
            // 
            this.SelectTrainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.SelectTrainer.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectTrainer.ForeColor = System.Drawing.Color.White;
            this.SelectTrainer.FormattingEnabled = true;
            this.SelectTrainer.Items.AddRange(new object[] {
            "Your Trainers",
            "Gym Trainers"});
            this.SelectTrainer.Location = new System.Drawing.Point(20, 155);
            this.SelectTrainer.Name = "SelectTrainer";
            this.SelectTrainer.Size = new System.Drawing.Size(124, 23);
            this.SelectTrainer.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(18, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 25;
            this.label5.Text = "Filter";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(15, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 28);
            this.label1.TabIndex = 21;
            this.label1.Text = "TRAINER";
            // 
            // report
            // 
            this.report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.report.FlatAppearance.BorderSize = 0;
            this.report.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.report.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.report.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.report.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report.ForeColor = System.Drawing.Color.SlateGray;
            this.report.Location = new System.Drawing.Point(367, 195);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(138, 52);
            this.report.TabIndex = 20;
            this.report.Text = "Add Review";
            this.report.UseVisualStyleBackColor = true;
            this.report.Click += new System.EventHandler(this.report_Click);
            // 
            // filter
            // 
            this.filter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.filter.FlatAppearance.BorderSize = 0;
            this.filter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.filter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filter.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filter.ForeColor = System.Drawing.Color.SlateGray;
            this.filter.Location = new System.Drawing.Point(367, 142);
            this.filter.Name = "filter";
            this.filter.Size = new System.Drawing.Size(138, 41);
            this.filter.TabIndex = 19;
            this.filter.Text = "Filter";
            this.filter.UseVisualStyleBackColor = true;
            this.filter.Click += new System.EventHandler(this.filter_Click);
            // 
            // metricRight
            // 
            this.metricRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.metricRight.Controls.Add(this.gymPrompt);
            this.metricRight.Controls.Add(this.label15);
            this.metricRight.Controls.Add(this.richTextBox2);
            this.metricRight.Controls.Add(this.label13);
            this.metricRight.Controls.Add(this.chooseGym);
            this.metricRight.Controls.Add(this.label4);
            this.metricRight.Controls.Add(this.gymRating);
            this.metricRight.Controls.Add(this.SelectGym);
            this.metricRight.Controls.Add(this.label7);
            this.metricRight.Controls.Add(this.report2);
            this.metricRight.Controls.Add(this.filter2);
            this.metricRight.Controls.Add(this.label2);
            this.metricRight.Dock = System.Windows.Forms.DockStyle.Left;
            this.metricRight.Location = new System.Drawing.Point(717, 38);
            this.metricRight.Name = "metricRight";
            this.metricRight.Size = new System.Drawing.Size(495, 631);
            this.metricRight.TabIndex = 16;
            // 
            // gymPrompt
            // 
            this.gymPrompt.AutoSize = true;
            this.gymPrompt.ForeColor = System.Drawing.Color.Crimson;
            this.gymPrompt.Location = new System.Drawing.Point(194, 57);
            this.gymPrompt.Name = "gymPrompt";
            this.gymPrompt.Size = new System.Drawing.Size(0, 13);
            this.gymPrompt.TabIndex = 36;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(24, 378);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 15);
            this.label15.TabIndex = 35;
            this.label15.Text = "Review";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.richTextBox2.Font = new System.Drawing.Font("Cascadia Code", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.ForeColor = System.Drawing.Color.White;
            this.richTextBox2.Location = new System.Drawing.Point(27, 396);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(219, 96);
            this.richTextBox2.TabIndex = 34;
            this.richTextBox2.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(24, 278);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 15);
            this.label13.TabIndex = 33;
            this.label13.Text = "Gym";
            // 
            // chooseGym
            // 
            this.chooseGym.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.chooseGym.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseGym.ForeColor = System.Drawing.Color.White;
            this.chooseGym.FormattingEnabled = true;
            this.chooseGym.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.chooseGym.Location = new System.Drawing.Point(24, 296);
            this.chooseGym.Name = "chooseGym";
            this.chooseGym.Size = new System.Drawing.Size(124, 23);
            this.chooseGym.TabIndex = 32;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(21, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 15);
            this.label4.TabIndex = 31;
            this.label4.Text = "Rating";
            // 
            // gymRating
            // 
            this.gymRating.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.gymRating.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gymRating.ForeColor = System.Drawing.Color.White;
            this.gymRating.FormattingEnabled = true;
            this.gymRating.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.gymRating.Location = new System.Drawing.Point(24, 213);
            this.gymRating.Name = "gymRating";
            this.gymRating.Size = new System.Drawing.Size(124, 23);
            this.gymRating.TabIndex = 30;
            // 
            // SelectGym
            // 
            this.SelectGym.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(53)))), ((int)(((byte)(93)))));
            this.SelectGym.Font = new System.Drawing.Font("Cascadia Code", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectGym.ForeColor = System.Drawing.Color.White;
            this.SelectGym.FormattingEnabled = true;
            this.SelectGym.Items.AddRange(new object[] {
            "Location"});
            this.SelectGym.Location = new System.Drawing.Point(24, 155);
            this.SelectGym.Name = "SelectGym";
            this.SelectGym.Size = new System.Drawing.Size(124, 23);
            this.SelectGym.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(21, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 15);
            this.label7.TabIndex = 28;
            this.label7.Text = "Filter";
            // 
            // report2
            // 
            this.report2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.report2.FlatAppearance.BorderSize = 0;
            this.report2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.report2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.report2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.report2.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report2.ForeColor = System.Drawing.Color.SlateGray;
            this.report2.Location = new System.Drawing.Point(313, 195);
            this.report2.Name = "report2";
            this.report2.Size = new System.Drawing.Size(138, 52);
            this.report2.TabIndex = 24;
            this.report2.Text = "Add Review";
            this.report2.UseVisualStyleBackColor = true;
            this.report2.Click += new System.EventHandler(this.report2_Click);
            // 
            // filter2
            // 
            this.filter2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.filter2.FlatAppearance.BorderSize = 0;
            this.filter2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Aqua;
            this.filter2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSeaGreen;
            this.filter2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filter2.Font = new System.Drawing.Font("Cascadia Code SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filter2.ForeColor = System.Drawing.Color.SlateGray;
            this.filter2.Location = new System.Drawing.Point(313, 142);
            this.filter2.Name = "filter2";
            this.filter2.Size = new System.Drawing.Size(138, 41);
            this.filter2.TabIndex = 23;
            this.filter2.Text = "Filter";
            this.filter2.UseVisualStyleBackColor = true;
            this.filter2.Click += new System.EventHandler(this.filter2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cascadia Code", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(19, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 28);
            this.label2.TabIndex = 22;
            this.label2.Text = "GYM";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // MemberMetric
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(58)))), ((int)(((byte)(75)))));
            this.ClientSize = new System.Drawing.Size(1212, 669);
            this.Controls.Add(this.metricRight);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.topside);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MemberMetric";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemberDash";
            this.menu.ResumeLayout(false);
            this.userInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.topside.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.metricRight.ResumeLayout(false);
            this.metricRight.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        public void MenuFormat()
        {
            menu.BackColor = Color.FromArgb(11, 35, 61);
            menu.Dock = System.Windows.Forms.DockStyle.Left;
        }
        public void TopFormat()
        {
            topside.BackColor = Color.LavenderBlush;
            topside.Dock = System.Windows.Forms.DockStyle.Top;
        }
        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Panel topside;
        private System.Windows.Forms.Button minimize;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel userInfo;
        private System.Windows.Forms.Button dashboard;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button DIET;
        private System.Windows.Forms.Button metrics;
        private System.Windows.Forms.Button PLAN;
        private System.Windows.Forms.Button trainers;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label welcome;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button report;
        private System.Windows.Forms.Button filter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel metricRight;
        private System.Windows.Forms.Button report2;
        private System.Windows.Forms.Button filter2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox SelectTrainer;
        private System.Windows.Forms.ComboBox SelectGym;
        private System.Windows.Forms.ComboBox Rating;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox gymRating;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox TrainerSelection;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox chooseTrainer;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox chooseGym;
        private System.Windows.Forms.Label trainerPrompt;
        private System.Windows.Forms.Label gymPrompt;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}