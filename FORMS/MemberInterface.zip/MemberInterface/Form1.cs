﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class Form1 : Form
    {
        private MemberReg register = null;
        private MemberDash dash = null;
        private string itemToCheck;
        public string name;
        public string email;
        public string password;
        public Form1()
        {
            InitializeComponent();
            exitLogin.MouseEnter += OnMouseEnterExitLogin;
            exitLogin.MouseLeave += OnMouseLeaveExitLogin;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            regBtn.MouseEnter += RegBtn_MouseEnter;
            regBtn.MouseLeave += RegBtn_MouseLeave;
        }

        private void RegBtn_MouseLeave(object sender, EventArgs e)
        {
            regBtn.ForeColor = Color.SlateGray;
        }

        private void RegBtn_MouseEnter(object sender, EventArgs e)
        {
            regBtn.ForeColor = Color.White;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.ForeColor = Color.Red;
            panel1.BackColor = Color.Red;
        }
        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                textBox2.Clear();

            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox3.ForeColor = Color.Red;
            panel3.BackColor = Color.Red;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.ForeColor == Color.White)
                 textBox2.Clear();
          
            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        private void OnMouseEnterExitLogin(object sender, EventArgs e)
        {
            exitLogin.ForeColor = Color.White;
        }
        private void OnMouseLeaveExitLogin(object sender, EventArgs e)
        {
            exitLogin.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }
        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exitLogin_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            register = new MemberReg();
            this.Hide();
            register.FormClosed += (s, args) => this.Close();
            register.Show();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            name = textBox1.Text.ToString();
            email = textBox3.Text.ToString();
            password = textBox2.Text.ToString();
            if(name.Length == 0 || email.Length == 0 || password.Length == 0)
            {
                prompt.Text = "Please fill in all details.";
            }
            else if(!email.Contains("@") || !email.Contains(".com")) {
                prompt.Text = "Invalid Email Try Again.";
                
            }
            else
            {
                //sql connect
                string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
                DataTable dataTable = new DataTable();
                string sqlQuery = "SELECT * FROM MEMBER WHERE name="+"'"+name+"'"+"AND email="+"'"+email+"'AND password= "+"'"+password+"';";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataTable);
                        }
                    }
                }
                
                foreach (DataRow row in dataTable.Rows)
                {
                    itemToCheck = row["verified"].ToString(); // Assuming "ColumnName" holds the data to display
                }
                if(itemToCheck == "0")
                {
                    prompt.Text = "Your Verification Is Not Completed!";
                      
                }
                else
                {
                    dash = new MemberDash(this);
                    dash.name = name;
                    dash.email = email;
                    dash.password = password;
                    this.Hide();
                    dash.FormClosed += (s, args) => this.Close();
                    dash.Show();
                }
            }
        }
    }
}
