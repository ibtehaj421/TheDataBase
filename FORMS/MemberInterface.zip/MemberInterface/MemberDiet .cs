﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class MemberDiet : Form
    {
        private MemberDash dash = null;
        private MemberWork plan = null;
        private MemberTrainers train = null;
        private MemberMetric metric = null;
        public string memberID; //will be transfered between all forms to make searches based on member ids.
        //also need to set a set as current diet plan feature to show on the main dashboard.
        public string[] mainReport = { "ID", "Type", "Nutrition", "Calorie", "Allergen" };
        public string[] otherReport = { "pID", "ID", "Type", "Nutrition", "Calorie", "Allergen" };
        public string[] mealHeaders;
        public string[] nutritionHeaders = { "ID","Name","Unit","Quantity","Calories" };
        public string[] allergenheaders = { "ID", "Name" };
        public bool show = true;
        public string query;
        public MemberDiet()
        {
            InitializeComponent();
            RunFunctions();
        }
        public MemberDiet(MemberDash other)
        {
            dash = other;
           // this.memberID = other.memberID;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 1000;
                timer1.Start();
                show = false;
            }
        }
        public MemberDiet(MemberWork other)
        {
            plan = other;
            //this.memberID = other.memberID;
            InitializeComponent();
            RunFunctions();
        }
        public MemberDiet(MemberTrainers other)
        {
            train = other;
            //this.memberID = other.memberID;
            InitializeComponent();
            RunFunctions();
        }
        public MemberDiet(MemberMetric other)
        {
            metric = other;
            //this.memberID = other.memberID;
            InitializeComponent();
            RunFunctions();
        }
        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            dashboard.MouseEnter += DIET_MouseEnterDIET;
            dashboard.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            addDiet.MouseLeave += AddDiet_MouseLeave;
            addDiet.MouseEnter += AddDiet_MouseEnter;
            filter.MouseEnter += Filter_MouseEnter;
            filter.MouseLeave += Filter_MouseLeave;
            report.MouseLeave += Report_MouseLeave;
            report.MouseEnter += Report_MouseEnter;
            setCurr.MouseEnter += SetCurr_MouseEnter;
            setCurr.MouseLeave += SetCurr_MouseLeave;
        }

        private void SetCurr_MouseLeave(object sender, EventArgs e)
        {
            setCurr.ForeColor = Color.SlateGray;
        }

        private void SetCurr_MouseEnter(object sender, EventArgs e)
        {
            setCurr.ForeColor = Color.White;
        }

        private void Report_MouseEnter(object sender, EventArgs e)
        {
            report.BackColor = Color.LightGreen;
            report.ForeColor = Color.Azure;
        }

        private void Report_MouseLeave(object sender, EventArgs e)
        {
            report.BackColor= Color.Transparent;
            report.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseLeave(object sender, EventArgs e)
        {
            filter.BackColor = Color.Transparent;
            filter.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseEnter(object sender, EventArgs e)
        {
            filter.BackColor = Color.LightGreen;
            filter.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseEnter(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.LightGreen;
            addDiet.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseLeave(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.Transparent;
            addDiet.ForeColor = Color.SlateGray;
        }

        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
           logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.SlateGray;
            
        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Aqua;
            dashboard.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Transparent;
            dashboard.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (dash != null)
            {
                dash.Close();
            }
            if (plan != null)
            {
                plan.Close();
            }
            if (metric != null)
            {
                metric.Close();
            }
            if (train != null)
            {
                train.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            //move to the diet form do nothing for now.
        }

        private void change_Click(object sender, EventArgs e)
        {

        }

        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void welcome_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dashboard_Click(object sender, EventArgs e)
        {
            dash = new MemberDash(this);
            dash.memberID = memberID;
            this.Hide();
            dash.FormClosed += (s, args) => this.Close();
            dash.Show();
        }

        private void PLAN_Click(object sender, EventArgs e)
        {
            plan = new MemberWork(this);
            plan.memberID = memberID;
            this.Hide();
            plan.FormClosed += (s, args) => this.Close();
            plan.Show();
        }

        private void metrics_Click(object sender, EventArgs e)
        {
            metric = new MemberMetric(this);
            metric.memberID = memberID;
            this.Hide();
            plan.FormClosed += (s, args) => this.Close();
            metric.Show();
        }

        private void trainers_Click(object sender, EventArgs e)
        {
            train = new MemberTrainers(this);
            train.memberID = memberID;
            this.Hide();
            train.FormClosed += (s, args) => this.Close();
            train.Show();
        }

        private void addDiet_Click(object sender, EventArgs e)
        {
            //use a procedure call to insert into 3 different tables.
            
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            query = "EXEC AddDietPlan @memberID='" + memberID + "' ,@nutri1='" + nutri1.Text + "' ,@nutri2='" + nutri2.Text + "' ,@type='" + dietType.Text + "' ,@objective='" + comboBox1.Text + "' ,@difficulty='" + difficulty.Text + "' ,@guideline='" + guideline.Text + "' ;";
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            timer3.Interval = 2000;
            timer3.Start();
            success.Text = "Diet Added Successfully..";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
        private void ShowMain()
        {
            //show all diet plans with nutrients etc.
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            DataTable table = new DataTable();
            string sqlQuery = "WITH dietReport AS(SELECT dietPlan_id as diet_id,meal_id,type FROM DIET_PLAN),extractAllergen AS(SELECT N.nutrition_id,N.name as nutrition,A.name as allergen FROM NUTRITION N JOIN ALLERGEN  A ON N.allergen_id = A.allergen_id)SELECT diet_id,type,nutrition,calorie,allergen FROM dietReport DP JOIN meal_nutrient MN ON DP.meal_id = MN.meal_id JOIN extractAllergen EA ON MN.nutrient_id = EA.nutrition_id ORDER BY diet_id;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            dietTable.Controls.Clear();
            for (int colIndex = 0; colIndex < mainReport.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = mainReport[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                dietTable.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in table.Rows)
            {
                for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    dietTable.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            ShowMain();
            LoadIntoList();
        }

        private void report_Click(object sender, EventArgs e)
        {
            //they both do the same work
            //report works on the first combo box
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            DataTable table = new DataTable();
            string capture = memberPlans.Text;
            
            if(capture.Length == 0)
            {
                //show prompt
                prompt.Text = "Choose A Selection!";
                timer2.Interval = 2000;
                timer2.Start();
                return;
            }
            else if(capture == "Members")
            {
                //show all member plans
              query = "WITH dietReport AS(\r\n\tSELECT M.member_id,D.dietPlan_id as diet_id,meal_id,type FROM DIET_PLAN D JOIN MEMBER_DIETS M ON D.dietPlan_id = M.diet_id),\r\n\textractAllergen AS(\r\n\tSELECT N.nutrition_id,N.name as nutrition,A.name as allergen FROM NUTRITION N JOIN ALLERGEN  A ON N.allergen_id = A.allergen_id)\r\n\tSELECT member_id,diet_id,type,nutrition,calorie,allergen FROM dietReport DP JOIN meal_nutrient MN ON DP.meal_id = MN.meal_id JOIN extractAllergen EA ON MN.nutrient_id = EA.nutrition_id ORDER BY member_id;\r\n";
            }
            else if(capture == "Self")
            {
                //show all your plans
                query = "WITH dietReport AS(\r\n\tSELECT M.member_id,D.dietPlan_id as diet_id,meal_id,type FROM DIET_PLAN D JOIN MEMBER_DIETS M ON M.diet_id = D.dietPlan_id WHERE member_id ='"+memberID+"'),\r\n\textractAllergen AS(\r\n\tSELECT N.nutrition_id,N.name as nutrition,A.name as allergen FROM NUTRITION N JOIN ALLERGEN  A ON N.allergen_id = A.allergen_id)\r\n\tSELECT member_id,diet_id,type,nutrition,calorie,allergen FROM dietReport DP JOIN meal_nutrient MN ON DP.meal_id = MN.meal_id JOIN extractAllergen EA ON MN.nutrient_id = EA.nutrition_id ORDER BY diet_id;";
            }
            else if(capture == "Trainers")
            {
                //show all trainer plans
                query = "WITH dietReport AS(\r\n\tSELECT M.trainer_id,D.dietPlan_id as diet_id,meal_id,type FROM DIET_PLAN D JOIN TRAINER_DIETPLAN M ON M.dietPlan_id = D.dietPlan_id),\r\n\textractAllergen AS(\r\n\tSELECT N.nutrition_id,N.name as nutrition,A.name as allergen FROM NUTRITION N JOIN ALLERGEN  A ON N.allergen_id = A.allergen_id)\r\n\tSELECT trainer_id,diet_id,type,nutrition,calorie,allergen FROM dietReport DP JOIN meal_nutrient MN ON DP.meal_id = MN.meal_id JOIN extractAllergen EA ON MN.nutrient_id = EA.nutrition_id ORDER BY trainer_id;";
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            dietTable.Controls.Clear();
            for (int colIndex = 0; colIndex < otherReport.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = otherReport[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                dietTable.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in table.Rows)
            {
                for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    dietTable.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
            dietSelectList.Items.Clear();
            string toadd;
            foreach (DataRow row in table.Rows)
            {
                toadd = row["diet_id"].ToString();
                dietSelectList.Items.Add(toadd);
            }
        }

        private void filter_Click(object sender, EventArgs e)
        {
            //they both do the same work
            //filter works on the second combo box
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            DataTable table = new DataTable();
            string capture = TrainersPlans.Text;
            if(capture.Length == 0)
            {
                prompt.Text = "Choose A Selection!";
                timer2.Interval = 2000;
                timer2.Start();
                return;
            }
            else if(capture == "Allergen")
            {
                query = "SELECT * FROM ALLERGEN ORDER BY allergen_id";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(table);
                        }
                    }
                }
                dietTable.Controls.Clear();

                for (int colIndex = 0; colIndex < allergenheaders.Length; colIndex++)
                {
                    Label headerLabel = new Label();
                    headerLabel.Text = allergenheaders[colIndex];
                    headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                    headerLabel.ForeColor = Color.Azure;
                    dietTable.Controls.Add(headerLabel, colIndex, 0);
                }
                int rowIndex = 1;
                foreach (DataRow row in table.Rows)
                {
                    for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                    {
                        Label label = new Label();
                        label.Text = row[colIndex].ToString();
                        label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                        label.ForeColor = Color.Azure;
                        // Set other control properties as needed (e.g., font size)

                        dietTable.Controls.Add(label, colIndex, rowIndex);
                    }

                    rowIndex++; // Keep track of row index for next iteration
                }

            }
            else if(capture == "Nutrients")
            {
                query = "SELECT nutrition_id,name,unit,quantity,calories FROM NUTRITION ORDER BY nutrition_id";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(table);
                        }
                    }
                }
                dietTable.Controls.Clear();
                for (int colIndex = 0; colIndex < nutritionHeaders.Length; colIndex++)
                {
                    Label headerLabel = new Label();
                    headerLabel.Text = nutritionHeaders[colIndex];
                    headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                    headerLabel.ForeColor = Color.Azure;
                    dietTable.Controls.Add(headerLabel, colIndex, 0);
                }
                int rowIndex = 1;
                foreach (DataRow row in table.Rows)
                {
                    for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                    {
                        Label label = new Label();
                        label.Text = row[colIndex].ToString();
                        label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                        label.ForeColor = Color.Azure;
                        // Set other control properties as needed (e.g., font size)

                        dietTable.Controls.Add(label, colIndex, rowIndex);
                    }

                    rowIndex++; // Keep track of row index for next iteration
                }
            }

        }
        private void LoadIntoList()
        {
            nutri1.Items.Clear();
            nutri2.Items.Clear();
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            query = "SELECT name FROM NUTRITION ORDER BY nutrition_id";
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            string ToAdd;
            foreach (DataRow row in dataTable.Rows)
            {
                ToAdd = row["name"].ToString(); 
                nutri1.Items.Add(ToAdd);
                nutri2.Items.Add(ToAdd);
            }
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            prompt.Text = "";
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            success.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //set a current diet plan.
            if (dietSelectList.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose Selection!";
                return;
            }
            string dietID = dietSelectList.Text;
            
            query = "UPDATE MEMBER SET dietPlan_id = '" + dietID + "' WHERE member_id='" + memberID + "';";
            string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            timer3.Interval = 2000;
            timer3.Start();
            success.Text = "Set As Current Diet..";
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void guideline_TextChanged(object sender, EventArgs e)
        {

        }

        private void logout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
