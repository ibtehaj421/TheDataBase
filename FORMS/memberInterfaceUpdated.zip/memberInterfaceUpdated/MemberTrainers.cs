﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class MemberTrainers : Form
    {
        private MemberDash dash = null;
        private MemberWork plan = null;
        private MemberMetric metric = null;
        private MemberDiet diet = null;
        public string memberID;
        private bool show = true;
        private string[] headers = { "ID", "Name", "Experience", "Clients", "Rating" };
        private string query;
        private string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
        public MemberTrainers()
        {
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberTrainers(MemberDiet other)
        {
            diet = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberTrainers(MemberDash other)
        {
            dash = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberTrainers(MemberMetric other)
        {
            metric = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        public MemberTrainers(MemberWork other)
        {
            plan = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer1.Interval = 500;
                timer1.Start();
                show = false;
            }
        }
        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            dashboard.MouseEnter += DIET_MouseEnterDIET;
            dashboard.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            DIET.MouseEnter += MouseEnterDIET;
            DIET.MouseLeave += EMouseLeaveDIET;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            addDiet.MouseLeave += AddDiet_MouseLeave;
            addDiet.MouseEnter += AddDiet_MouseEnter;
            filter.MouseEnter += Filter_MouseEnter;
            filter.MouseLeave += Filter_MouseLeave;
            
        }
        private void EMouseLeaveDIET(object sender, EventArgs e)
        {
            DIET.BackColor = Color.Transparent;
            DIET.ForeColor = Color.SlateGray;
        }  
        private void MouseEnterDIET(object sender,EventArgs e)
        {
            DIET.BackColor = Color.Aqua;
            DIET.ForeColor = Color.Azure;
        }

        private void Filter_MouseLeave(object sender, EventArgs e)
        {
            filter.BackColor = Color.Transparent;
            filter.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseEnter(object sender, EventArgs e)
        {
            filter.BackColor = Color.LightGreen;
            filter.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseEnter(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.LightGreen;
            addDiet.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseLeave(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.Transparent;
            addDiet.ForeColor = Color.SlateGray;
        }

        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
           logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
           // trainers.ForeColor = Color.SlateGray;
        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Aqua;
            dashboard.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Transparent;
            dashboard.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (diet != null)
            {
                diet.Close();
            }
            if (plan != null)
            {
                plan.Close();
            }
            if (metric != null)
            {
                metric.Close();
            }
            if (dash != null)
            {
                dash.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            //move to the diet form do nothing for now.
            diet = new MemberDiet(this);
            diet.memberID = memberID;
            this.Hide();
            diet.FormClosed += (s, args) => this.Close();
            diet.Show();
        }

        private void change_Click(object sender, EventArgs e)
        {

        }

        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void welcome_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dashboard_Click(object sender, EventArgs e)
        {
            dash = new MemberDash(this);
            dash.memberID = memberID;
            this.Hide();
            dash.FormClosed += (s, args) => this.Close();
            dash.Show();
        }

        private void PLAN_Click(object sender, EventArgs e)
        {
            plan = new MemberWork(this);
            plan.memberID = memberID;
            this.Hide();
            plan.FormClosed += (s, args) => this.Close();
            plan.Show();
        }

        private void metrics_Click(object sender, EventArgs e)
        {
            metric = new MemberMetric(this);
            metric.memberID = memberID;
            this.Hide();
            metric.FormClosed += (s, args) => this.Close();
            metric.Show();
        }
        private void loadInitial()
        {
            query = "WITH SpecificTrainer AS(\r\n\tSELECT trainer_id,gym_id FROM TRAINING_SESSION WHERE member_id ='" + memberID + "'\r\n\t)\r\n\tSELECT T.trainer_id,T.name,T.experience,T.clients,T.rating FROM SpecificTrainer ST JOIN TRAINER T ON ST.trainer_id = T.trainer_id JOIN GYM G ON ST.gym_id = G.gym_id; ";
           
            DataTable table = new DataTable();
            dietTable.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            for (int colIndex = 0; colIndex < headers.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = headers[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                dietTable.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in table.Rows)
            {
                for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    dietTable.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
        }
        private void filter_Click(object sender, EventArgs e)
        {
            //first check which filter is required.
            if(trainerFilter.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose Selection!";
                return;
            }
            else if(trainerFilter.Text == "All")
            {
                query = "WITH specific AS(\r\n\tSELECT membership_id FROM MEMBER WHERE member_id = '"+memberID+"'\r\n\t),\r\n\tspecificGym AS(\r\n\tSELECT gym_id FROM Membership M JOIN specific S on M.membership_id = S.membership_id\r\n\t),\r\n\tspecificTrain AS(\r\n\tSELECT trainer_id FROM TRAINER_GYM T JOIN specificGym S ON T.gym_id = S.gym_id\r\n\t)\r\n\tSELECT T.trainer_id,T.name,T.experience,T.clients,T.rating FROM specificTrain S join TRAINER T on T.trainer_id = S.trainer_id; ";
            }
            else if(trainerFilter.Text == "Personal")
            {
                query = "WITH SpecificTrainer AS(\r\n\tSELECT trainer_id,gym_id FROM TRAINING_SESSION WHERE member_id ='"+memberID+"'\r\n\t)\r\n\tSELECT T.trainer_id,T.name,T.experience,T.clients,T.rating FROM SpecificTrainer ST JOIN TRAINER T ON ST.trainer_id = T.trainer_id JOIN GYM G ON ST.gym_id = G.gym_id; ";
            }
            else if(trainerFilter.Text == "Rating")
            {
                if(ratingBox.Text.Length == 0)
                {
                    prompt.ForeColor = Color.Red;
                    prompt.Text = "Choose Selection!";
                    return;
                }
                query = "WITH specific AS(\r\n\tSELECT membership_id FROM MEMBER WHERE member_id = '"+memberID+"'\r\n\t),\r\n\tspecificGym AS(\r\n\tSELECT gym_id FROM Membership M JOIN specific S on M.membership_id = S.membership_id\r\n\t),\r\n\tspecificTrain AS(\r\n\tSELECT trainer_id FROM TRAINER_GYM T JOIN specificGym S ON T.gym_id = S.gym_id\r\n\t)\r\n\tSELECT T.trainer_id,T.name,T.experience,T.clients,T.rating FROM specificTrain S join TRAINER T on T.trainer_id = S.trainer_id WHERE T.rating > "+float.Parse(ratingBox.Text)+"; ";
            }
            else if(trainerFilter.Text == "Experience")
            {
                if(expBox.Text.Length == 0)
                {
                    prompt.ForeColor = Color.Red;
                    prompt.Text = "Choose Selection!";
                    return;
                }
                query = "WITH specific AS(\r\n\tSELECT membership_id FROM MEMBER WHERE member_id = '"+memberID+"'\r\n\t),\r\n\tspecificGym AS(\r\n\tSELECT gym_id FROM Membership M JOIN specific S on M.membership_id = S.membership_id\r\n\t),\r\n\tspecificTrain AS(\r\n\tSELECT trainer_id FROM TRAINER_GYM T JOIN specificGym S ON T.gym_id = S.gym_id\r\n\t)\r\n\tSELECT T.trainer_id,T.name,T.experience,T.clients,T.rating FROM specificTrain S join TRAINER T on T.trainer_id = S.trainer_id WHERE T.experience >='"+ expBox.Text+"'; ";
            }
          
            DataTable table = new DataTable();
            dietTable.Controls.Clear();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            for (int colIndex = 0; colIndex < headers.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = headers[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                dietTable.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in table.Rows)
            {
                for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    dietTable.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
            string ToAdd;
            
            foreach (DataRow row in table.Rows)
            {
                ToAdd = row["name"].ToString();

                sessionList.Items.Add(ToAdd + "," + row["trainer_id"].ToString());
               
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            loadInitial();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            prompt.Text = " ";
        }

        private void addDiet_Click(object sender, EventArgs e)
        {
            //add a session to the trainer sessions
            if(sessionList.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose Selection!";
                return;
            }
            string trainerID = sessionList.Text;
            string[] idArray = trainerID.Split(',');
            string trimID = idArray[1].Trim();
            query = "EXEC RequestSession @memberID ='"+memberID+"',@trainerID='"+trimID+"';";
            
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            timer2.Interval = 2000;
            timer2.Start();
            prompt.ForeColor = Color.Green;
            prompt.Text = "Session Placed..";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (sessionList.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose Selection!";
                return;
            }
            string trainerID = sessionList.Text;
            string[] idArray = trainerID.Split(',');
            string trimID = idArray[1].Trim();
            query = "UPDATE MEMBER SET trainer_id = '" + trimID + "' WHERE member_id='" + memberID + "';";
           
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            timer2.Interval = 2000;
            timer2.Start();
            prompt.ForeColor = Color.Green;
            prompt.Text = "Set As Current..";
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
