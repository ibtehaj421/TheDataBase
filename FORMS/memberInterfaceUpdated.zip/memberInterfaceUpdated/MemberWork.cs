﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TrainerInterface
{
    public partial class MemberWork : Form
    {
        private MemberDash dash = null;
        private MemberTrainers train = null;
        private MemberDiet diet = null;
        private MemberMetric metric = null;
        public string memberID;
        public string query;
        private bool show = true;
        private string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
        string[] filter1Headers = { "ID", "Exercise", "Sets", "Reps", "Rest","Day"};

        public MemberWork()
        {
            InitializeComponent();
            RunFunctions();
        }
        public MemberWork(MemberDiet other)
        {
            diet = other;
            InitializeComponent();
            RunFunctions(); 
        }
        public MemberWork(MemberDash other)
        {
            dash = other;
            InitializeComponent();
            RunFunctions();
        }
        public MemberWork(MemberMetric other)
        {
            metric = other;
            InitializeComponent();
            RunFunctions();
        }
        public MemberWork(MemberTrainers other)
        {
            train = other;
            InitializeComponent();
            RunFunctions();
        }
        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            dashboard.MouseEnter += DIET_MouseEnterDIET;
            dashboard.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            addDiet.MouseLeave += AddDiet_MouseLeave;
            addDiet.MouseEnter += AddDiet_MouseEnter;
            filter.MouseEnter += Filter_MouseEnter;
            filter.MouseLeave += Filter_MouseLeave;
            report.MouseLeave += Report_MouseLeave;
            report.MouseEnter += Report_MouseEnter;
            currBTN.MouseEnter += CurrBTN_MouseEnter;
            currBTN.MouseLeave += CurrBTN_MouseLeave;
        }

        private void CurrBTN_MouseLeave(object sender, EventArgs e)
        {
           currBTN.ForeColor = Color.SlateGray;
        }

        private void CurrBTN_MouseEnter(object sender, EventArgs e)
        {
            currBTN.ForeColor = Color.White;
        }

        private void Report_MouseEnter(object sender, EventArgs e)
        {
            report.BackColor = Color.LightGreen;
            report.ForeColor = Color.Azure;
        }

        private void Report_MouseLeave(object sender, EventArgs e)
        {
            report.BackColor= Color.Transparent;
            report.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseLeave(object sender, EventArgs e)
        {
            filter.BackColor = Color.Transparent;
            filter.ForeColor = Color.SlateGray;
        }

        private void Filter_MouseEnter(object sender, EventArgs e)
        {
            filter.BackColor = Color.LightGreen;
            filter.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseEnter(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.LightGreen;
            addDiet.ForeColor = Color.Azure;
        }

        private void AddDiet_MouseLeave(object sender, EventArgs e)
        {
            addDiet.BackColor = Color.Transparent;
            addDiet.ForeColor = Color.SlateGray;
        }

        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
           logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.SlateGray;
            
        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Aqua;
            dashboard.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            dashboard.BackColor = Color.Transparent;
            dashboard.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            //PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (dash != null)
            {
                dash.Close();
            }
            if (train != null)
            {
                train.Close();
            }
            if (metric != null)
            {
                metric.Close();
            }
            if (diet != null)
            {
                diet.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            //move to the diet form do nothing for now.
            diet = new MemberDiet(this);
            diet.memberID = memberID;
            this.Hide();
            diet.FormClosed += (s, args) => this.Close();
            diet.Show();
        }

        private void change_Click(object sender, EventArgs e)
        {

        }

        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void welcome_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void dashboard_Click(object sender, EventArgs e)
        {
            dash = new MemberDash(this);
            dash.memberID = memberID;
            this.Hide();
            dash.FormClosed += (s, args) => this.Close();
            dash.Show();
        }

        private void metrics_Click(object sender, EventArgs e)
        {
            metric = new MemberMetric(this);
            metric.memberID = memberID;
            this.Hide();
            metric.FormClosed += (s, args) => this.Close();
            metric.Show();
        }

        private void trainers_Click(object sender, EventArgs e)
        {
            train = new MemberTrainers(this);
            train.memberID = memberID;
            this.Hide();
            train.FormClosed += (s, args) => this.Close();
            train.Show();
        }

        private void filter_Click(object sender, EventArgs e)
        {
            //filter on the basis of muscle or difficulty.
          
            DataTable table = new DataTable();
            
            if (FilterPlan.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt2.Text = "Choose Selection!";
                prompt2.ForeColor = Color.Crimson;
                return;
            }
            else if(FilterPlan.Text == "Difficulty")
            {
                //now select from the difficulty2 text box
                if(targetDifficulty.Text.Length == 0)
                {
                    timer2.Interval = 2000;
                    timer2.Start();
                    prompt2.Text = "Choose Selection!";
                    prompt2.ForeColor = Color.Crimson;
                    return;
                }
                //query
                query = "WITH SpecificPlan AS(\r\n\tSELECT workoutPlan_id FROM WORKOUT_PLAN WHERE difficulty_level = '"+targetDifficulty.Text+"'),\r\n\tSpecificExercise AS(\r\n\tSELECT SP.workoutPlan_id,E.name,E.sets,E.reps,E.restIntervals,E.day_id FROM EXERCISE E JOIN SpecificPlan SP ON E.workoutPlan_id = SP.workoutPlan_id)\r\n\tSELECT SE.workoutPlan_id,SE.name,SE.sets,SE.reps,SE.restIntervals,D.dayOfWeek FROM SpecificExercise SE JOIN DAY D ON SE.day_id = D.day_id;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(table);
                        }
                    }
                }
                dietTable.Controls.Clear();
                for (int colIndex = 0; colIndex < filter1Headers.Length; colIndex++)
                {
                    Label headerLabel = new Label();
                    headerLabel.Text = filter1Headers[colIndex];
                    headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                    headerLabel.ForeColor = Color.Azure;
                    dietTable.Controls.Add(headerLabel, colIndex, 0);
                }
                int rowIndex = 1;
                foreach (DataRow row in table.Rows)
                {
                    for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                    {
                        Label label = new Label();
                        label.Text = row[colIndex].ToString();
                        label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                        label.ForeColor = Color.Azure;
                        // Set other control properties as needed (e.g., font size)

                        dietTable.Controls.Add(label, colIndex, rowIndex);
                    }

                    rowIndex++; // Keep track of row index for next iteration
                }

            }
            else if(FilterPlan.Text == "Muscle")
            {
                //now select from the muscle text box
                if(targetMuscle.Text.Length == 0)
                {
                    timer2.Interval = 2000;
                    timer2.Start();
                    prompt2.Text = "Choose Selection!";
                    prompt2.ForeColor = Color.Crimson;
                    return;
                }
                query = "WITH muscleEx AS (\r\n\tSELECT exercise_id FROM MUSCLE WHERE name = '"+targetMuscle.Text+"'),\r\n\tspEX AS(\r\n\tSELECT SP.workoutPlan_id,SP.name,SP.sets,SP.reps,SP.restIntervals FROM muscleEx M JOIN EXERCISE SP ON M.exercise_id = SP.exercise_id)\r\n\tSELECT SP.workoutPlan_id,SP.name,SP.sets,SP.reps,SP.restIntervals,D.dayOfWeek FROM spEX SP JOIN DAY D ON SP.workoutPlan_id = D.workoutPlan_id;";
                //query
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(table);
                        }
                    }
                }
                dietTable.Controls.Clear();
                for (int colIndex = 0; colIndex < filter1Headers.Length; colIndex++)
                {
                    Label headerLabel = new Label();
                    headerLabel.Text = filter1Headers[colIndex];
                    headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                    headerLabel.ForeColor = Color.Azure;
                    dietTable.Controls.Add(headerLabel, colIndex, 0);
                }
                int rowIndex = 1;
                foreach (DataRow row in table.Rows)
                {
                    for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                    {
                        Label label = new Label();
                        label.Text = row[colIndex].ToString();
                        label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                        label.ForeColor = Color.Azure;
                        // Set other control properties as needed (e.g., font size)

                        dietTable.Controls.Add(label, colIndex, rowIndex);
                    }

                    rowIndex++; // Keep track of row index for next iteration
                }
            }
            currentSet.Items.Clear();
            string toadd;
            
            foreach (DataRow row in table.Rows)
            {
                toadd = row["workoutPlan_id"].ToString();
                currentSet.Items.Add(toadd);
            }
        }

        private void report_Click(object sender, EventArgs e)
        {
            //generate a report based on all members only trainers only or self.
            
            DataTable table = new DataTable();
            if (workPlans.Text.Length == 0)
            {
                timer2.Interval = 2000;
                timer2.Start();
                prompt2.Text = "Choose Selection!";
                prompt2.ForeColor = Color.Crimson;
                return;
            }
            else if(workPlans.Text == "Trainers")
            {
                query = "WITH SpecificPlan AS(\r\n\tSELECT workoutPlan_id FROM TRAINER_WORKOUTPLAN),\r\n\tSpecificEx AS(\r\n\tSELECT SP.workoutPlan_id,E.name,E.sets,E.reps,E.restIntervals,E.day_id FROM EXERCISE E JOIN SpecificPlan SP ON E.workoutPlan_id = SP.workoutPlan_id)\r\n\tSELECT SE.workoutPlan_id,SE.name,SE.sets,SE.reps,SE.restIntervals,D.dayOfWeek FROM SpecificEx SE JOIN DAY D ON SE.day_id = D.day_id;";
            }
            else if(workPlans.Text == "Members")
            {
                query = "WITH SpecificPlan AS(\r\n\tSELECT DISTINCT(work_id) FROM MEMBER_WORKOUT WHERE member_id NOT IN ('"+memberID+"')),\r\n\tSpecificEx AS(\r\n\tSELECT SP.work_id,E.name,E.sets,E.reps,E.restIntervals,E.day_id FROM EXERCISE E JOIN SpecificPlan SP ON E.workoutPlan_id = SP.work_id)\r\n\tSELECT SE.work_id,SE.name,SE.sets,SE.reps,SE.restIntervals,D.dayOfWeek FROM SpecificEx SE JOIN DAY D ON SE.day_id = D.day_id;\r\n";
            }
            else if (workPlans.Text == "Self")
            {
                query = "WITH SpecificPlan AS(\r\n\tSELECT DISTINCT(work_id) FROM MEMBER_WORKOUT WHERE member_id IN ('" + memberID + "')),\r\n\tSpecificEx AS(\r\n\tSELECT SP.work_id,E.name,E.sets,E.reps,E.restIntervals,E.day_id FROM EXERCISE E JOIN SpecificPlan SP ON E.workoutPlan_id = SP.work_id)\r\n\tSELECT SE.work_id,SE.name,SE.sets,SE.reps,SE.restIntervals,D.dayOfWeek FROM SpecificEx SE JOIN DAY D ON SE.day_id = D.day_id;\r\n";

            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(table);
                    }
                }
            }
            dietTable.Controls.Clear();
            for (int colIndex = 0; colIndex < filter1Headers.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = filter1Headers[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                dietTable.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in table.Rows)
            {
                for (int colIndex = 0; colIndex < table.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    dietTable.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
            string toadd;
            currentSet.Items.Clear();
            foreach (DataRow row in table.Rows)
            {
                toadd = row["workoutPlan_id"].ToString();
                currentSet.Items.Add(toadd);
            }
        }

        private void objective_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void addDiet_Click(object sender, EventArgs e)
        {
            //add to work out plan for a person.
            if(ex1.Text.Length == 0 || objective.Text.Length == 0 || difficulty.Text.Length == 0 || Weekday.Text.Length == 0 || equipment.Text.Length == 0 || guidelines.Text.Length == 0 || Sets.Text.Length == 0 || Reps.Text.Length == 0 || restInt.Text.Length == 0) {
                //return function with a error message.
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose All Selections!";
                timer2.Interval = 2000;
                timer2.Start();
                return;
            }
            SqlConnection conn = null;
            query = "EXEC AddWorkPlan @memberID='"+memberID+"',@Exercise='"+ex1.Text+"',@objective='"+objective.Text+"',@difficulty='"+difficulty.Text+"',@dayofweek='"+Weekday.Text+"',@equipment='"+equipment.Text+"',@guideline='"+guidelines.Text+"',@sets="+int.Parse(Sets.Text)+",@reps="+int.Parse(Reps.Text)+",@rest="+int.Parse(restInt.Text)+";";
            
            conn = new SqlConnection(connectionString);
            SqlCommand cmd;
            conn.Open();
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            prompt.ForeColor = Color.Green;
            prompt.Text = "Plan Added Successfully..";
            timer2.Interval = 2000;
            timer2.Start();
            ex1.Text = "";
            objective.Text = "";
            difficulty.Text = "";
            Weekday.Text = "";
            equipment.Text = "";
            guidelines.Text = "";
            Sets.Text = "";
            Reps.Text = "";
            restInt.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //prompt timers.
            timer2.Stop();
            prompt.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void currBTN_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            query = "UPDATE MEMBER SET workoutPlan_id = '" + currentSet.Text + "' WHERE member_id = '" + memberID + "';";
            if (currentSet.Text.Length == 0)
            {
                prompt.ForeColor = Color.Red;
                prompt.Text = "Choose All Selections!";
                timer2.Interval = 2000;
                timer2.Start();
                conn.Close();
                return;
            }
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            conn.Close();
            prompt.ForeColor = Color.Green;
            prompt.Text = "Plan Added Successfully..";
            timer2.Interval = 2000;
            timer2.Start();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
