﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TrainerInterface
{
    public partial class MemberDash : Form
    {
        private MemberDiet diet =null;
        private MemberWork plan = null;
        private MemberTrainers train = null;
        private MemberMetric metric = null;
        private Form1 login = null;
        public string name = null;
        public string password;
        public string email;
        public string memberID;
        public string dietplan = "D10";
        public string workplan;
        private bool show = true;
        private string sqlQuery;
        private string[] columnheaders = { "Excercise", "Sets", "Reps" };
        private string[] columnHeader1 = { "Type", "Obejctive", "Calories" };
        private string[] columnHeader2 = { "Name", "Gym", "Experience" };
        private string connectionString = "Data Source=YGGDRASIL\\SQLEXPRESS;Initial Catalog=testDB3;Integrated Security=True";
        public MemberDash()
        {
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer2.Interval = 500;
                timer2.Start();
                show = false;
            }
        }
        public MemberDash(MemberDiet other)
        {
            diet = other;
            
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer2.Interval = 500;
                timer2.Start();
                
                show = false;
            }
        }
        public MemberDash(MemberWork other)
        {
            plan = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer2.Interval =500;
                timer2.Start();
                show = false;
            }
        }
        public MemberDash(MemberTrainers other)
        {
            train = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer2.Interval = 500;
                timer2.Start();
     
                show = false;
            }
        }
        public MemberDash(MemberMetric other)
        {
            metric = other;
            InitializeComponent();
            RunFunctions();
            if (show)
            {
                timer2.Interval = 500;
                timer2.Start();
                show = false;
            }
        }
        public MemberDash(Form1 login)
        {
            this.login = login;
            InitializeComponent ();
            RunFunctions();
            if (show)
            {
                timer2.Interval = 500;
                timer2.Start();
                show = false;
            }
        }
        private void MemberDash_Load(object sender, EventArgs e)
        {
            if (name != null)
            {
                usernamelbl.Text = login.name;
            }
        }
        private void RunFunctions()
        {
            exit.MouseEnter += OnMouseEnterExit;
            exit.MouseLeave += OnMouseLeaveExit;
            minimize.MouseEnter += OnMouseEnterMinimize;
            minimize.MouseLeave += OnMouseLeaveMinimize;
            DIET.MouseEnter += DIET_MouseEnterDIET;
            DIET.MouseLeave += MouseLeaveDIET;
            PLAN.MouseEnter += OnMouseEnterPlan;
            PLAN.MouseLeave += OnMouseLeavePlan;
            metrics.MouseLeave += OnMouseLeaveMetric;
            metrics.MouseEnter += OnMouseEnterMetric;
            trainers.MouseEnter += Trainers_MouseEnter;
            trainers.MouseLeave += Trainers_MouseLeave;
            logout.MouseEnter += Logout_MouseEnter;
            logout.MouseLeave += Logout_MouseLeave;
            change.MouseEnter += Change_MouseEnter;
            change.MouseLeave += Change_MouseLeave;
        }
        private void Change_MouseEnter(object sender, EventArgs e)
        {
            change.BackColor = Color.LightGreen;
            change.ForeColor = Color.Azure;
        }
        private void Change_MouseLeave(object sender, EventArgs e)
        {
            change.BackColor = Color.Transparent;
        }
        private void Logout_MouseLeave(object sender, EventArgs e)
        {
            logout.BackColor = Color.Transparent;
        }

        private void Logout_MouseEnter(object sender, EventArgs e)
        {
           logout.BackColor = Color.PaleVioletRed;
            logout.ForeColor = Color.Azure;
        }

        private void Trainers_MouseLeave(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.SlateGray;
            
        }

        private void Trainers_MouseEnter(object sender, EventArgs e)
        {
            trainers.ForeColor = Color.Azure;
        }

        private void DIET_MouseEnterDIET(object sender, EventArgs e)
        {
            DIET.BackColor = Color.Aqua;
            DIET.ForeColor = Color.Azure;
        }
        private void MouseLeaveDIET(object sender, EventArgs e)
        {
            DIET.BackColor = Color.Transparent;
            DIET.ForeColor = Color.SlateGray;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void FormDeets()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            MenuFormat();
            TopFormat();
        }
        private void OnMouseEnterExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveExit(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterPlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.White;
        }
        private void OnMouseLeavePlan(object sender, EventArgs e)
        {
            PLAN.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.White;
        }
        private void OnMouseLeaveMetric(object sender, EventArgs e)
        {
            metrics.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.White;
        }
        private void OnMouseLeaveTrainer(object sender, EventArgs e)
        {
            exit.ForeColor = Color.SlateGray;
        }
        private void OnMouseEnterMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.White;
        }
        private void OnMouseLeaveMinimize(object sender, EventArgs e)
        {
            minimize.ForeColor = Color.SlateGray;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if(diet != null)
            {
                diet.Close();
            }
            if(plan!= null)
            {
                plan.Close();
            }
            if(metric!= null)
            {
                metric.Close();
            }
            if(train!= null)
            {
                train.Close();
            }
            Close();
        }

        private void DIET_Click(object sender, EventArgs e)
        {
            diet = new MemberDiet(this);
            diet.memberID = memberID;
            this.Hide();
            diet.FormClosed += (s, args) => this.Close();
            diet.Show();
        }
        private void SetUserInfo()
        {
           
            //usernamelbl.Text = email;
            
            DataTable dataTable = new DataTable();
            if (name != null)
            {
                 sqlQuery = "SELECT * FROM MEMBER WHERE name=" + "'" + name + "'" + "AND email=" + "'" + email + "'AND password= " + "'" + password + "';";
            }
            else
            {
                sqlQuery = "SELECT * FROM MEMBER WHERE member_id='"+memberID + "';";
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            foreach (DataRow row in dataTable.Rows)
            {
                usernamelbl.Text = row["name"].ToString(); 
                memberID = row["member_id"].ToString();
                dietplan = row["dietPlan_id"].ToString();
                workplan = row["workoutPlan_id"].ToString();
            }
        }
        private void change_Click(object sender, EventArgs e)
        {
            //detects the text box info in the change text boxes and then sends an update query.
           
            SqlCommand cmd;
            SqlConnection connection = new SqlConnection(connectionString);
            string changeUsr = nameChange.Text;
            string changePass = passChange.Text;
            string changeMail = emailChange.Text;
            if(changeUsr.Length > 0)
            {
                //change the user name
                connection.Open();
                string query = "UPDATE MEMBER SET name = '" + changeUsr + "' WHERE member_id = '" + memberID + "';";
                cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cmd.Clone();
            }
            else if(changePass.Length > 0)
            {
                //cchange the users password
                connection.Open();
                string query = "UPDATE MEMBER SET name = '" + changePass + "' WHERE member_id = '" + memberID + "';";
                cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cmd.Clone();
            }
            else if(changeMail.Length > 0)
            {
                //change the users email
                connection.Open();
                string query = "UPDATE MEMBER SET name = '" + changeMail + "' WHERE member_id = '" + memberID + "';";
                cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cmd.Clone();
            }
            else
            {
                //show label with error message.
                label3.Text = "Select Something To Change!";
                timer1.Interval = 2000;
                timer1.Start();
            }
        }
        private void timer1_tick(object sender, EventArgs e)
        {
            
        }
        private void currentWP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void PLAN_Click(object sender, EventArgs e)
        {
            plan = new MemberWork(this);
            plan.memberID = memberID;
            this.Hide();
            plan.FormClosed += (s, args) => this.Close();
            plan.Show();
        }

        private void metrics_Click(object sender, EventArgs e)
        {
            metric = new MemberMetric(this);
            metric.memberID = memberID;
            this.Hide();
            metric.FormClosed += (s, args) => this.Close();
            metric.Show();
        }

        private void trainers_Click(object sender, EventArgs e)
        {
            train = new MemberTrainers(this);
            train.memberID = memberID;
            this.Hide();
            train.FormClosed += (s, args) => this.Close();
            train.Show();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void passChange_TextChanged(object sender, EventArgs e)
        {

        }

        private void loadDetails()
        {
           
            string sqlQuery = "SELECT name,sets,reps FROM EXERCISE WHERE workoutPlan_id ='"+workplan+"' ;"; 
            string sqlQuery2 = "WITH SpecificDiet AS(SELECT type,objective,meal_id FROM DIET_PLAN WHERE dietPlan_id = '"+dietplan+"'"+"),MealCals AS(SELECT meal_id,SUM(calorie) as cals FROM meal_nutrient GROUP BY meal_id)SELECT SD.type,SD.objective,MC.cals FROM SpecificDiet SD JOIN MealCals MC ON SD.meal_id = MC.meal_id;";
            string sqlQuery3 = "WITH TrainerGym AS(SELECT trainer_id,gym_id FROM TRAINING_SESSION WHERE member_id = '"+memberID+"')SELECT T.name,G.name,T.experience FROM TRAINER T JOIN TrainerGym TG ON T.trainer_id = TG.trainer_id JOIN GYM G ON G.gym_id = TG.gym_id;";
            DataTable dataTable = new DataTable();
            DataTable dataTable2 = new DataTable();
            DataTable dataTable3 = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            
            currentWP.Controls.Clear();
            for (int colIndex = 0; colIndex < columnheaders.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = columnheaders[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                currentWP.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex = 1;
            foreach (DataRow row in dataTable.Rows)
            {
                for (int colIndex = 0; colIndex < dataTable.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    // Set other control properties as needed (e.g., font size)

                    currentWP.Controls.Add(label, colIndex, rowIndex);
                }

                rowIndex++; // Keep track of row index for next iteration
            }
            rowIndex++;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery2, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable2);
                    }
                }
            }
            for (int colIndex = 0; colIndex < columnheaders.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = columnHeader1[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                currentWP.Controls.Add(headerLabel, colIndex, rowIndex);
            }
            rowIndex++;
            foreach (DataRow row in dataTable2.Rows)
            {
                for (int colIndex = 0; colIndex < dataTable2.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    currentWP.Controls.Add(label, colIndex, rowIndex);
                }
            }
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery3, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable3);
                    }
                }
            }
            tableLayoutPanel1.Controls.Clear();
            for (int colIndex = 0; colIndex < columnHeader2.Length; colIndex++)
            {
                Label headerLabel = new Label();
                headerLabel.Text = columnHeader2[colIndex];
                headerLabel.Font = new Font("Cascadia code", 12, FontStyle.Bold);
                headerLabel.ForeColor = Color.Azure;
                tableLayoutPanel1.Controls.Add(headerLabel, colIndex, 0);
            }
            int rowIndex2 = 1;
            foreach (DataRow row in dataTable3.Rows)
            {
                for (int colIndex = 0; colIndex < dataTable3.Columns.Count; colIndex++)
                {
                    Label label = new Label();
                    label.Text = row[colIndex].ToString();
                    label.Font = new Font("Cascadia code", 11, FontStyle.Regular);
                    label.ForeColor = Color.Azure;
                    tableLayoutPanel1.Controls.Add(label, colIndex, rowIndex2);
                }
                rowIndex2++;
            }
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            label3.Text = "";
            timer1.Stop();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            SetUserInfo();
            loadDetails();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void logout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
