﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TrainerInterface
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            string username = Form1.username;
            string password = Form1.password;
            string email = Form1.email;
            textBox1.Text = username;
            textBox8.Text = email;
            textBox9.Text = password;
            textBox10.Text = username;
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT M.member_id AS 'Member ID', M.name AS 'Member Name', N.expiry AS 'Membership Duration', N.type AS 'Membership Type' FROM Member M JOIN Membership N ON M.membership_id = N.membership_id";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt.Tables[0];
            feedbackText.Show();
            appointmentText.Hide();
            AddPanel.Hide();
            RemoveMember.Hide();
            RemoveTrainer.Hide();
            dataGridView2.Hide();
            textBox13.Click += textBox13_Click;
            textBox14.Click += textBox14_Click;
            textBox15.Click += textBox15_Click;
            textBox16.Click += textBox16_Click;
            textBox12.Click += textBox12_Click;
            textBox17.Click += textBox17_Click;
            textBox20.Click += textBox20_Click;
            textBox21.Click += textBox21_Click;
            textBox22.Click += textBox22_Click;
            textBox23.Click += textBox23_Click;
            textBox24.Click += textBox24_Click;
            textBox11.Hide();
            button7.Hide();
            button8.Hide();
            button9.Hide();
            textBox25.Hide();
            textBox26.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // New Selection
            button1.BackColor = Color.Red;
            pictureBox2.BackColor = Color.Red;

            // Potential Previous Selection
            button2.BackColor = Color.Black;
            pictureBox3.BackColor = Color.Black;

            button3.BackColor = Color.Black;
            pictureBox4.BackColor = Color.Black;
            
            button4.BackColor = Color.Black;
            pictureBox5.BackColor = Color.Black;

            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT M.member_id AS 'Member ID', M.name AS 'Member Name', N.expiry AS 'Membership Duration', N.type AS 'Membership Type' FROM Member M JOIN Membership N ON M.membership_id = N.membership_id";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt.Tables[0];

            // Show Screen
            feedbackText.Show();
            appointmentText.Hide();
            AddTrainer.Hide();
            AddPanel.Hide();
            RemoveMember.Hide();
            RemoveTrainer.Hide();
            ManageAccounts.Hide();
            dataGridView1.Show();
            dataGridView2.Hide();
            textBox11.Hide();
            button7.Hide();
            button8.Hide();
            button9.Hide();
            button10.Show();
            button11.Show();
            textBox25.Hide();
            textBox26.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // New Selection
            button2.BackColor = Color.Red;
            pictureBox3.BackColor = Color.Red;

            // Potential Previous Selection
            button1.BackColor = Color.Black;
            pictureBox2.BackColor = Color.Black;

            button3.BackColor = Color.Black;
            pictureBox4.BackColor = Color.Black;

            button4.BackColor = Color.Black;
            pictureBox5.BackColor = Color.Black;

            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT T.trainer_id AS 'Trainer ID', T.name AS 'Trainer Name', T.rating AS 'Rating', T.clients AS 'No. of Clients', T.experience AS 'Experience' FROM Trainer T\r\n";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt.Tables[0];

            feedbackText.Hide();
            appointmentText.Show();
            AddTrainer.Hide();
            AddPanel.Hide();
            RemoveMember.Hide();
            RemoveTrainer.Hide();
            ManageAccounts.Hide();
            dataGridView1.Hide();
            dataGridView2.Show();
            textBox11.Show();
            button7.Show();
            button8.Show();
            button9.Show();
            button10.Hide();
            button11.Hide();
            textBox25.Show();
            textBox26.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // New Selection
            button3.BackColor = Color.Red;
            pictureBox4.BackColor = Color.Red;

            // Potential Previous Selection
            button1.BackColor = Color.Black;
            pictureBox2.BackColor = Color.Black;

            button2.BackColor = Color.Black;
            pictureBox3.BackColor = Color.Black;

            button4.BackColor = Color.Black;
            pictureBox5.BackColor = Color.Black;

            AddTrainer.Show();
            AddPanel.Show();
            RemoveMember.Hide();
            RemoveTrainer.Hide();
            ManageAccounts.Hide();
            feedbackText.Hide();
            appointmentText.Hide();
            dataGridView1.Hide();
            dataGridView2.Hide();
            textBox11.Hide();
            button7.Hide();
            button8.Hide();
            button9.Hide();
            button10.Hide();
            button11.Hide();
            textBox25.Hide();
            textBox26.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // New Selection
            button4.BackColor = Color.Red;
            pictureBox5.BackColor = Color.Red;

            // Potential Previous Selection
            button2.BackColor = Color.Black;
            pictureBox3.BackColor = Color.Black;

            button3.BackColor = Color.Black;
            pictureBox4.BackColor = Color.Black;

            button1.BackColor = Color.Black;
            pictureBox2.BackColor = Color.Black;

            RemoveMember.Show();
            RemoveTrainer.Show();
            ManageAccounts.Show();
            AddTrainer.Hide();
            AddPanel.Hide();
            textBox18.Show();
            textBox19.Show();
            feedbackText.Hide();
            appointmentText.Hide();
            dataGridView1.Hide();
            dataGridView2.Hide();
            textBox11.Hide();
            button7.Hide();
            button8.Hide();
            button9.Hide();
            button10.Hide();
            button11.Hide();
            textBox25.Hide();
            textBox26.Hide();
        }
        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void feedbackText_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox14_Click(object sender, EventArgs e)
        {
            textBox14.Clear();
            textBox14.ForeColor = Color.Red;
            panel7.BackColor = Color.Red;
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_Click(object sender, EventArgs e)
        {
            textBox13.Clear();
            textBox13.ForeColor = Color.Red;
            panel6.BackColor = Color.Red;
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_Click(object sender, EventArgs e)
        {
            textBox12.Clear();
            textBox12.ForeColor = Color.Red;
            panel5.BackColor = Color.Red;
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox16_Click(object sender, EventArgs e)
        {
            textBox16.Clear();
            textBox16.ForeColor = Color.Red;
            panel9.BackColor = Color.Red;
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_Click(object sender, EventArgs e)
        {
            textBox15.Clear();
            textBox15.ForeColor = Color.Red;
            panel8.BackColor = Color.Red;
        }
        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox22_Click(object sender, EventArgs e)
        {
            textBox22.Clear();
            textBox22.ForeColor = Color.Red;
            panel12.BackColor = Color.Red;
        }
        private void textBox23_Click(object sender, EventArgs e)
        {
            textBox23.Clear();
            textBox23.ForeColor = Color.Red;
            panel15.BackColor = Color.Red;
        }
        private void textBox24_Click(object sender, EventArgs e)
        {
            textBox24.Clear();
            textBox24.ForeColor = Color.Red;
            panel16.BackColor = Color.Red;
        }
        private void textBox17_Click(object sender, EventArgs e)
        {
            textBox17.Clear();
            textBox17.ForeColor = Color.Red;
            panel10.BackColor = Color.Red;
        }
        private void textBox20_Click(object sender, EventArgs e)
        {
            textBox20.Clear();
            textBox20.ForeColor = Color.Red;
            panel13.BackColor = Color.Red;
        }
        private void textBox21_Click(object sender, EventArgs e)
        {
            textBox21.Clear();
            textBox21.ForeColor = Color.Red;
            panel14.BackColor = Color.Red;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string rating = textBox25.Text;
            if (!string.IsNullOrEmpty(rating))
            {
                SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                conn.Open();
                string query = "SELECT T.trainer_id AS 'Trainer ID', T.name AS 'Trainer Name', T.rating AS 'Rating', T.clients AS 'No. of Clients', T.experience AS 'Experience' FROM Trainer T WHERE T.rating >= '" + rating + "' ORDER BY rating DESC";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataSet dt = new DataSet();
                adapter.Fill(dt);
                dataGridView2.DataSource = dt.Tables[0];
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string experience = textBox26.Text;
            if (!string.IsNullOrEmpty(experience))
            {
                SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                conn.Open();
                string query = "SELECT T.trainer_id AS 'Trainer ID', T.name AS 'Trainer Name', T.rating AS 'Rating', T.clients AS 'No. of Clients', T.experience AS 'Experience' FROM Trainer T WHERE T.experience >= '" + experience + "'  ORDER BY experience DESC";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataSet dt = new DataSet();
                adapter.Fill(dt);
                dataGridView2.DataSource = dt.Tables[0];
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT T.trainer_id AS 'Trainer ID', T.name AS 'Trainer Name', T.rating AS 'Rating', T.clients AS 'No. of Clients', T.experience AS 'Experience' FROM Trainer T";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt.Tables[0];
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string name = textBox14.Text;
            string qualifications = textBox13.Text;
            string specialty = textBox16.Text;
            string experience = textBox12.Text;
            string email = textBox15.Text;
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(qualifications) && !string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(specialty) && !string.IsNullOrEmpty(email))
            {
                SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                string query = "SELECT * FROM Trainer";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                int rows = dt.Rows.Count + 1;
                string trainerID = "T" + rows.ToString();

                query = "SELECT * FROM Speciality";
                adapter = new SqlDataAdapter(query, conn);
                dt = new DataTable();
                adapter.Fill(dt);
                rows = dt.Rows.Count + 1;
                string specialtyID = "SP" + rows.ToString();
                conn.Open();

                SqlCommand com;
                query = "Insert into Trainer (trainer_id, name, email, experience) values ('" + trainerID + "','" + name + "','" + email + "','" + experience + "')";
                com = new SqlCommand(query, conn);
                com.ExecuteNonQuery();
                com.Dispose();

                query = "Insert into Speciality values ('" + specialtyID + "','" + trainerID + "','" + specialty + "')";
                com = new SqlCommand(query, conn);
                com.ExecuteNonQuery();
                com.Dispose();

                MessageBox.Show("Trainer added");
            }
            else
            {
                MessageBox.Show("Fill all input fields");
            }
        }

        private void Login_Click(object sender, EventArgs e)
        {
            string id = textBox17.Text;
            string name = textBox21.Text;
            string reasons = textBox20.Text;
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(reasons))
            {
                SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                string query = "DELETE FROM Member WHERE member_id = '" + id + "' AND [name] = '" + name + "'";
                SqlCommand com;
                conn.Open();
                com = new SqlCommand(query, conn);
                com.ExecuteNonQuery();
                com.Dispose();
                MessageBox.Show("Member Removed");
            }
            else
            {
                MessageBox.Show("Fill all input fields");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string id = textBox22.Text;
            string name = textBox24.Text;
            string reasons = textBox23.Text;
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(reasons))
            {
                SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                string query = "DELETE FROM Speciality WHERE trainer_id = '" + id + "'";
                SqlCommand com;
                conn.Open();
                com = new SqlCommand(query, conn);
                com.ExecuteNonQuery();
                com.Dispose();
                query = "DELETE FROM Trainer WHERE trainer_id = '" + id + "' AND [name] = '" + name + "'";
                com = new SqlCommand(query, conn);
                com.ExecuteNonQuery();
                com.Dispose();
                MessageBox.Show("Trainer Removed");
            }
            else
            {
                MessageBox.Show("Fill all input fields");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT* FROM Membership M WHERE DATEDIFF(MONTH , getdate(), expiry) >= 9";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt.Tables[0];
        }

        private void button11_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            conn.Open();
            string query = "SELECT M.member_id AS 'Member ID', M.name AS 'Member Name', N.expiry AS 'Membership Duration', N.type AS 'Membership Type' FROM Member M JOIN Membership N ON M.membership_id = N.membership_id";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataSet dt = new DataSet();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt.Tables[0];
        }
    }
}
