﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainerInterface
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            textBox6.Click += textBox6_Click;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.ForeColor = Color.Red;
            panel1.BackColor = Color.Red;
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox3.ForeColor = Color.Red;
            panel3.BackColor = Color.Red;
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
            textBox4.ForeColor = Color.Red;
            panel5.BackColor = Color.Red;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox2.ForeColor = Color.Red;
            panel2.BackColor = Color.Red;
        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            textBox5.Clear();
            textBox5.ForeColor = Color.Red;
            panel6.BackColor = Color.Red;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create an instance of the login form
            Form1 loginForm = new Form1();

            this.Hide();
            loginForm.Closed += (s, args) => this.Close();
            // Show the login form
            loginForm.Show();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            textBox6.Clear();
            textBox6.ForeColor = Color.Red;
            panel7.BackColor = Color.Red;
        }

        private void Login_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string repassword = textBox2.Text;
            string email = textBox3.Text;
            string password = textBox4.Text;
            string name = textBox5.Text;
            string gymName = textBox6.Text;
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(repassword) && !string.IsNullOrEmpty(gymName))
            {
                if (password == repassword)
                {
                    SqlConnection conn = new SqlConnection("Data Source=LAPTOP-OTQD26O3\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                    string query = "SELECT * FROM Owner";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    int rows = dt.Rows.Count + 1;
                    string ownerID = "O" + rows.ToString();

                    query = "SELECT * FROM Gym";
                    adapter = new SqlDataAdapter(query, conn);
                    dt = new DataTable();
                    adapter.Fill(dt);
                    rows = dt.Rows.Count + 1;
                    string gymID = "G" + rows.ToString();
                    conn.Open();

                    SqlCommand com;
                    query = "Insert into Owner values ('" + ownerID + "','" + name + "','" + username + "','" + email + "','" + password + "')";
                    com = new SqlCommand(query, conn);
                    com.ExecuteNonQuery();
                    com.Dispose();

                    query = "Insert into Gym values ('" + gymID + "','" + ownerID + "','" + gymName + "', NULL, NULL, NULL, NULL)";
                    com = new SqlCommand(query, conn);
                    com.ExecuteNonQuery();
                    com.Dispose();

                    conn.Close();
                    MessageBox.Show("Sign up successful");
                    this.Hide();
                    var Login = new Form1();
                    Login.Closed += (s, args) => this.Close();
                    Login.Show();
                }
                else
                {
                    MessageBox.Show("Passwords don't match");
                }
            }
            else
            {
                MessageBox.Show("Fill all input fields");
            }
        }
    }
}
